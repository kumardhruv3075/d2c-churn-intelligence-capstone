# Data Quality Report
## D2C Churn Intelligence – Part 1

**Snapshot Date:** 2024-06-30  
**Analyst:** Churn Intelligence Team  
**Datasets Reviewed:** 7 (customers, orders, support_tickets, web_app_events, campaigns, churn_labels, modeling_snapshot)

---

## 1. Summary of Datasets

| Dataset | Rows | Columns | Primary Key |
|---|---|---|---|
| customers | 3,000 | 9 | customer_id |
| orders | 10,219 | 10 | order_id |
| support_tickets | 2,759 | 8 | ticket_id |
| web_app_events | 58,342 | 5 | — (event log) |
| campaigns | 7,495 | 6 | — (campaign log) |
| churn_labels | 3,000 | 3 | customer_id |
| modeling_snapshot | 3,000 | 24 | customer_id |

---

## 2. Missing Values

| Dataset | Column | Missing Count | Missing % | Recommendation |
|---|---|---|---|---|
| support_tickets | resolution_days | 600 | 21.7% | Expected: NULL when ticket is unresolved. Create `is_resolved` flag. |
| modeling_snapshot | — | 0 | 0.0% | No issues |
| customers | — | 0 | 0.0% | No issues |
| orders | — | 0 | 0.0% | No issues |

**Action:** `resolution_days = NULL` is structurally valid (ticket not closed). Do NOT impute with 0 — create a binary `resolved` column separately (already exists).

---

## 3. Duplicate Records

| Dataset | Duplicate Primary Keys | Action |
|---|---|---|
| customers | 0 | None required |
| orders | 0 | None required |
| support_tickets | 0 | None required |

No duplicate key violations found.

---

## 4. Invalid or Unusual Values

| Dataset | Column | Issue | Count | Recommendation |
|---|---|---|---|---|
| orders | net_amount | Values above 99th pctile (₹9,413) | 103 | Flag for outlier treatment; likely multi-item bulk orders — valid. |
| orders | is_returned | Returned orders still have positive net_amount | All | Net amount is pre-return; recalculate refund value separately. |
| tickets | escalated=True but resolved=True | Contradictory? | ~80 | Both can be true; escalated then resolved — acceptable. |
| customers | age | Range 18–64; no nulls | 0 | Reasonable for personal-care brand. |
| web_app_events | session_duration_sec | Max ~1799 sec (30 min) | — | Cap appears intentional; watch for sessions of exactly 1800 (truncated). |

---

## 5. Outliers

**Orders – Net Amount:**
- Median: ₹1,480
- 95th pctile: ₹7,234
- 99th pctile: ₹9,414
- Max: ~₹14,500

**Recommendation:** Keep outliers in EDA; winsorize or log-transform for modeling.

**Support Ticket – Resolution Days:**
- Range: 1–14 days among resolved tickets
- No extreme outliers detected

---

## 6. Join / Key Issues

All `customer_id` values in orders, tickets, events, and campaigns match a valid customer in the `customers` table. No orphaned records found.

**Web events:** 1 customer (of 3,000) has no event records — likely very new or opted out of digital tracking.

---

## 7. Date Consistency Issues

| Check | Result |
|---|---|
| Order dates before customer join date | 0 found |
| Ticket dates before customer join date | 0 found |
| Order dates after snapshot (2024-06-30) | 0 found |
| Campaign dates after snapshot | 0 found |

Date ordering is consistent. No temporal leakage detected in raw data.

---

## 8. Potential Leakage Columns

> ⚠️ These columns must NOT be used as model features if they are derived from post-snapshot data.

| Column | Risk | Notes |
|---|---|---|
| `churned` (churn_labels) | **Target** – never a feature | The prediction target itself |
| Any order/event after snapshot_date | **Direct leakage** | All feature engineering must use data ≤ snapshot_date |
| `resolution_days` for future tickets | **Leakage** | Only tickets before snapshot are used in snapshot file |
| Post-campaign outcome (converted) after snapshot | **Leakage** | Campaign conversion must be filtered to pre-snapshot |

**Mitigation:** The `modeling_snapshot.csv` has already been constructed using only pre-snapshot data. Verify by checking no feature references post-2024-06-30 data.

---

## 9. Overall Assessment

| Category | Status | Priority |
|---|---|---|
| Missing Values | ✅ Minor – only `resolution_days` | Low |
| Duplicates | ✅ None found | — |
| Outliers | ⚠️ Present in monetary columns | Medium |
| Join Integrity | ✅ Clean | — |
| Date Consistency | ✅ Clean | — |
| Leakage Risk | ⚠️ Managed in snapshot; must verify custom features | High |

The dataset is overall clean and well-structured. Primary risks are outlier treatment for monetary features and strict temporal discipline during feature engineering.
