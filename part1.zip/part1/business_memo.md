# Business Memo
## To: Product, Marketing & Customer Support Leadership
## From: Data & Analytics Team
## Subject: Priority Patterns to Investigate Before Launching Retention Campaign
## Date: July 2024

---

### TL;DR

Our exploratory analysis of 3,000 customers reveals a **74% overall churn rate** — significantly high and driven by identifiable, actionable patterns. Before spending on blanket retention campaigns, we recommend focusing on five specific risk areas backed by data.

---

### 1. The Tier Problem Is Our Biggest Lever

**Bronze-tier customers (45% of our base) churn at ~76%.** Platinum customers churn at under 15%. This is not random — tier reflects engagement depth, purchase frequency, and basket size. A Bronze customer who has purchased only once or twice is already a near-certain churner unless we intervene.

**Action required:** Design a tier-upgrade path with clear, achievable milestones. Customers stuck in Bronze are invisibly churning while we ignore them.

---

### 2. Recency Is the Loudest Warning Signal

Customers who last ordered more than 60 days before the snapshot date churn at **over 80%**. Those who ordered within the last 30 days churn at under 30%.

This means we have a narrow intervention window. By the time a customer hits Day 45 of inactivity, the probability of recovery drops sharply.

**Action required:** Implement a 30-day inactivity trigger that routes customers into a winback flow automatically — before we lose them.

---

### 3. Support Tickets Are Unsatisfied Customers in Disguise

Customers with 3 or more support tickets show markedly higher churn. Many of these tickets relate to delivery delays, wrong products, and quality issues. Our current resolution rate of ~78% means roughly 600 tickets were never closed — and those customers are still watching.

**Action required:** Audit all unresolved tickets older than 7 days. Personally reach out to customers with escalated or unresolved complaints — this is a retention intervention, not just a support task.

---

### 4. Discount-Driven Buyers Are Not Loyal Customers

Customers with average discount usage above 15% actually churn at a **higher rate** than moderate buyers. This counterintuitive finding suggests that heavy discounting attracts price-sensitive customers who leave when promotions dry up — not long-term brand loyalists.

**Action required:** Before extending deeper discounts in the next retention campaign, test whether loyalty-based rewards (early access, free samples, tier upgrades) produce better long-term retention than price cuts.

---

### 5. Campaign Non-Engagement Is a Churn Precursor

Customers who never open a single campaign message are significantly more likely to churn. Email and SMS open rates are already tracked; this data should feed directly into a churn-risk score.

**Action required:** Customers with 0 campaign opens in the last 60 days should be flagged for channel-switch outreach — if email doesn't work, try WhatsApp, in-app push, or a personal call for high-value accounts.

---

### What to Do Before the Campaign Launches

| Priority | Action | Owner |
|---|---|---|
| 1 | Set up a 30-day inactivity trigger with automated winback | CRM/Eng |
| 2 | Resolve all 600+ unresolved support tickets immediately | Customer Support |
| 3 | Audit Bronze-tier customers with ≥2 orders for upgrade candidacy | Marketing |
| 4 | Test non-discount retention offers with discount-heavy segment | Marketing |
| 5 | Build campaign-engagement signal into churn scoring | Analytics |

---

### What We Should Not Do

- **Do not send a blanket discount** to all 3,000 customers. ~26% are retained and loyal; discounting them erodes margin without benefit.
- **Do not treat all Bronze customers the same.** Some are new customers who haven't had time to purchase more — they need nurture, not winback.
- **Do not wait 90 days** to declare someone at risk. Our data shows the window closes well before then.

---

*This memo is based on exploratory data analysis of the customer, order, support, and engagement datasets as of snapshot date 2024-06-30. Predictive model output (Part 3) will provide individual-level churn probability scores to sharpen targeting further.*
