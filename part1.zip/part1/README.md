# Part 1 — Data Audit, EDA & Business Understanding
## D2C Customer Churn Intelligence

### Overview
This repository contains the full exploratory data analysis (EDA) and data audit for a D2C personal-care brand's customer churn intelligence project. It covers 3,000 customers, 10,219 orders, 2,759 support tickets, 58,342 web/app events, and 7,495 campaign interactions across a 2.5-year period up to snapshot date **2024-06-30**.

---

### Repository Structure

```
part1/
├── README.md                  ← This file
├── eda_audit.ipynb            ← Main analysis notebook
├── eda_audit.py               ← Python script version of the notebook
├── data_quality_report.md     ← Detailed data quality findings
├── business_memo.md           ← Business-facing recommendations memo
├── requirements.txt           ← Python dependencies
└── charts/                    ← Saved chart outputs (8 charts)
    ├── chart1_churn_distribution.png
    ├── chart2_churn_by_tier.png
    ├── chart3_recency_distribution.png
    ├── chart4_frequency_vs_churn.png
    ├── chart5_tickets_vs_churn.png
    ├── chart6_revenue_by_category.png
    ├── chart7_discount_vs_churn.png
    └── chart8_age_distribution.png
```

---

### Dataset

The data package contains:

| File | Description |
|---|---|
| `customers.csv` | 3,000 customer profiles with demographics, tier, channel |
| `orders.csv` | 10,219 orders with amount, category, discount, return flag |
| `support_tickets.csv` | 2,759 support interactions with sentiment and resolution |
| `web_app_events.csv` | 58,342 digital engagement events |
| `campaigns.csv` | 7,495 marketing campaign touchpoints |
| `churn_labels.csv` | Binary churn label per customer (snapshot: 2024-06-30) |
| `modeling_snapshot.csv` | Pre-built feature table for modeling (Parts 3 & 4) |

Place all files in a `../data/` folder relative to this repository (or adjust `DATA_DIR` path in the notebook).

---

### Setup & Run

```bash
# Clone and install
pip install -r requirements.txt

# Run as Jupyter Notebook
jupyter notebook eda_audit.ipynb

# Or run as Python script
python eda_audit.py
```

---

### Key Findings

| Finding | Evidence |
|---|---|
| Overall churn rate: **74%** | churn_labels.csv |
| Bronze tier churn: **~76%** | Chart 2 |
| 60+ day inactive → **>80% churn** | Chart 3 |
| 3+ support tickets → elevated churn | Chart 5 |
| Heavy discounters churn more | Chart 7 |

---

### Churn-Risk Hypotheses

1. **H1 – High Recency → High Churn:** Days since last order is the strongest predictor
2. **H2 – Tier as Loyalty Depth:** Bronze churn rate is 5× that of Platinum
3. **H3 – Support Ticket Volume:** Each additional ticket elevates churn probability
4. **H4 – Campaign Non-Engagement:** Zero-open customers are pre-churners
5. **H5 – Discount Dependency:** Heavy discount usage signals price-sensitive, disloyal buyers

---

### Data Quality Summary

- ✅ No duplicate records in any dataset
- ✅ No referential integrity violations
- ✅ No date ordering issues (orders after snapshot, etc.)
- ⚠️ `resolution_days` is NULL for 21.7% of support tickets (unresolved — expected)
- ⚠️ Monetary outliers at 99th pctile (₹9,413) — valid bulk orders, handle in modeling
- ⚠️ Leakage risk: any feature using post-2024-06-30 data must be excluded from model

See [data_quality_report.md](data_quality_report.md) for full details.
