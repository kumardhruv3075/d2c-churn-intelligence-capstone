# Part 2 — RFM Segmentation & Retention Strategy
## D2C Customer Churn Intelligence

### Overview
This repository builds customer segments using RFM (Recency, Frequency, Monetary) analysis combined with behavioural signals (support tickets, campaign engagement, returns, digital activity) for a D2C personal-care brand. It produces actionable retention recommendations for each segment.

---

### Repository Structure

```
part2/
├── README.md                    ← This file
├── rfm_segmentation.ipynb       ← Main analysis notebook
├── rfm_segmentation.py          ← Python script version
├── segments.csv                 ← Customer-level segment assignments
├── retention_strategy.md        ← Per-segment retention playbook + budget plan
├── manual_review_cases.md       ← 10 edge-case customers with individual reasoning
├── requirements.txt             ← Python dependencies
└── charts/
    ├── rfm_segment_distribution.png
    ├── rfm_churn_by_segment.png
    ├── rfm_heatmap.png
    └── rfm_recency_by_segment.png
```

---

### Segments Defined (9 Segments)

| Segment | Customers | Churn Rate | Primary Signal |
|---|---|---|---|
| Needs Attention | 853 | 51% | High freq+spend, moderate recency |
| At-Risk | 1,131 | 95% | Low R+F; dormant buyers |
| Loyal Customers | 588 | 72% | Moderate RFM, consistent buying |
| Champions | 293 | 67% | High R_score; recent purchase |
| Promising | 46 | 37% | Recent + high frequency |
| High-Value Unhappy | 62 | 90% | High M, multiple negative tickets |
| Discount-Sensitive | 17 | 59% | Heavy discounters, near-zero open rate |
| Dormant | 4 | 100% | Very long inactive |
| New Customers | 6 | 0% | Joined <90 days |

---

### RFM Scoring Logic

- **Recency (R):** Days since last order — scored 1–5 (5 = most recent)
- **Frequency (F):** Total order count — scored 1–5 (5 = highest)
- **Monetary (M):** Total net spend — scored 1–5 (5 = highest)
- **Combined RFM Score:** R + F + M (range: 3–15)

### Additional Signals

1. Support ticket count and sentiment (negative/very negative)
2. Campaign open rate (engagement with marketing)
3. Return rate per customer
4. Average discount % used
5. Web/app events in last 30 days

---

### Setup & Run

```bash
pip install -r requirements.txt

# Run as script
python rfm_segmentation.py

# Or as notebook
jupyter notebook rfm_segmentation.ipynb
```

Data files must be in `../data/` relative to this directory.

---

### Key Outputs

- `segments.csv` — customer_id, segment_name, RFM scores, behavioural signals
- `retention_strategy.md` — full retention playbook with ₹500K budget allocation
- `manual_review_cases.md` — 10 edge cases with case-by-case reasoning
