# Manual Review Cases
## 10 Customers Where Retention Decision Is Not Obvious

**Snapshot Date:** 2024-06-30 | **Analyst:** Churn Intelligence Team

> These cases are selected because their RFM segment, churn label, or behavioural signals conflict with each other — making the standard retention playbook inadequate.

---

### Case 1 — C00044 | Segment: Champions | Churned: 0 (Retained)

| Signal | Value |
|---|---|
| Recency | 9 days (very recent) |
| Frequency | 1 order |
| Monetary | ₹2,758 |
| Support Tickets | 3 (all neutral sentiment) |
| Churn Label | **Retained** |

**Why It's Unclear:** This customer is classified as Champion due to very recent activity and high R_score, but they have only ONE order and 3 support tickets in a short time. They are brand-new but already having issues. The label says "retained," but 3 tickets in 9 days is unusual.

**Decision:** Do NOT treat as loyal. Assign to the High-Value Unhappy watch list. Proactively resolve all tickets before sending any promotional message. One more bad experience and they will churn at the next snapshot.

---

### Case 2 — C00085 | Segment: Champions | Churned: 1

| Signal | Value |
|---|---|
| Recency | 50 days |
| Frequency | 1 order |
| Monetary | ₹797 |
| Negative Tickets | 2 |
| Churn Label | **Churned** |

**Why It's Unclear:** Classified as Champion (decent R_score) but churned with low spend and 2 negative tickets. The recency (50 days) is borderline — the model scored them well on recency but they never came back.

**Decision:** Winback is low ROI here (₹797 LTV). Send a single low-cost recovery email addressing their support issues. If no response in 14 days, suppress from further campaigns.

---

### Case 3 — C00087 | Segment: Champions | Churned: 0

| Signal | Value |
|---|---|
| Recency | 16 days |
| Frequency | 2 orders |
| Monetary | ₹4,207 |
| Return Rate | **50%** |
| Negative Tickets | 2 |
| Churn Label | Retained |

**Why It's Unclear:** Recent activity and decent spend, but returns HALF their orders. This customer is engaged but dissatisfied with specific products. The 2 negative tickets confirm this.

**Decision:** Do not send a generic promotion. Instead, reach out with a product recommendation consultation — they are clearly trying to find the right product but failing. A recommendation engine or live chat session could save this relationship.

---

### Case 4 — C00009 | Segment: Needs Attention | Churned: 1

| Signal | Value |
|---|---|
| Recency | 44 days |
| Frequency | 5 orders |
| Monetary | ₹20,835 |
| Support Tickets | 0 |
| Avg Discount | 6% |
| Churn Label | **Churned** |

**Why It's Unclear:** This is one of the most counterintuitive cases: 5 orders, ₹20K spend, no complaints, low discount usage — yet they churned. This could mean a life-event (moved away, switched preferences, found a competitor with a better assortment).

**Decision:** This is a high-priority winback candidate. Contact with a personalized "We noticed you haven't been back" message and ask directly what changed — gather qualitative insight. The spend history justifies a personal phone outreach.

---

### Case 5 — C00019 | Segment: Needs Attention | Churned: 1

| Signal | Value |
|---|---|
| Recency | 5 days (very recent!) |
| Frequency | 4 orders |
| Monetary | ₹13,622 |
| Support Tickets | 3 |
| Return Rate | 0% |
| Churn Label | **Churned** |

**Why It's Unclear:** Purchased just 5 days ago but labelled as churned. This is likely a data timing anomaly — the label was generated on the snapshot date (June 30) and this customer's "churn" may be defined by a future observation window that has not yet triggered based on a very recent order.

**Decision:** Flag as a likely **false churn label**. Do NOT include in winback campaign. Monitor for the next 30 days — if they purchase again they confirm as retained.

---

### Case 6 — C00017 | Segment: Needs Attention | Churned: 1

| Signal | Value |
|---|---|
| Recency | 31 days |
| Frequency | 4 orders |
| Monetary | ₹30,161 |
| Support Tickets | 1 |
| Return Rate | 0% |
| Churn Label | **Churned** |

**Why It's Unclear:** Highest spend among manual review cases. 4 orders, no returns, 1 ticket. 31 days recency — very close to the borderline. This is almost certainly a high-value customer who is slipping.

**Decision:** **Top priority winback.** Assign to a senior retention specialist. Offer a curated loyalty gift box and a Platinum upgrade path. ROI is exceptional if retained (₹30K LTV).

---

### Case 7 — C00006 | Segment: Loyal Customers | Churned: 1

| Signal | Value |
|---|---|
| Recency | 98 days |
| Frequency | 1 order |
| Monetary | ₹1,438 |
| Avg Discount | 0% |
| Support Tickets | 1 |
| Churn Label | **Churned** |

**Why It's Unclear:** Segment says "Loyal" but this customer has only 1 order and 98-day recency — they should have been classified as At-Risk or Dormant. The segment label is likely a scoring boundary issue.

**Decision:** Do not treat as loyal. Apply the At-Risk playbook — one low-cost email. With only ₹1,438 spend, do not allocate high-value retention budget.

---

### Case 8 — C00025 | Segment: Loyal Customers | Churned: 1

| Signal | Value |
|---|---|
| Recency | 12 days (very recent) |
| Frequency | 2 orders |
| Monetary | ₹8,046 |
| Support Tickets | 2 |
| Avg Discount | 0% |
| Churn Label | **Churned** |

**Why It's Unclear:** Purchased 12 days ago but churned. Same issue as C00019 — likely a label timing issue, not a true churn. However the 2 tickets warrant monitoring.

**Decision:** Mark as potentially mislabelled. Resolve support tickets first. Send a follow-up survey asking about their experience. Do not treat as confirmed churner.

---

### Case 9 — C00021 | Segment: Loyal Customers | Churned: 1

| Signal | Value |
|---|---|
| Recency | 40 days |
| Frequency | 3 orders |
| Monetary | ₹9,093 |
| Support Tickets | 0 |
| Avg Discount | 0% |
| Churn Label | **Churned** |

**Why It's Unclear:** 3 orders, ₹9K spend, no complaints, no discounts — this is a genuine brand buyer who churned without any warning signal in the data. No tickets, no returns, no discount dependency.

**Decision:** This is likely a **competitor capture** case. Send an NPS survey to understand why they left. Offer a personalized "comeback" incentive based on their past purchases. Gather qualitative insight to improve retention of this profile.

---

### Case 10 — C00115 | Segment: Champions | Churned: 1

| Signal | Value |
|---|---|
| Recency | 28 days |
| Frequency | 1 order |
| Monetary | ₹534 |
| Support Tickets | 2 |
| Negative Tickets | 1 |
| Churn Label | **Churned** |

**Why It's Unclear:** Low value (₹534), recently active but churned, and has 2 tickets for a single order. This is a dissatisfied first-time buyer who had a bad experience and left.

**Decision:** Low ROI to retain (₹534 LTV). However, this profile is important for **brand perception** — one bad first experience means a likely negative review. Send a genuine service recovery email. If they respond, address the complaint. Do not offer a monetary incentive — just acknowledge the issue.

---

## Summary Observations

| Pattern | Count | Action |
|---|---|---|
| Recently active but churned (recency < 30d) | 3 | Investigate label accuracy; likely false positives |
| High-spend (>₹9K) with no complaint, churned | 3 | Competitor capture; qualitative outreach priority |
| Good segment label but high ticket load | 2 | Product/service recovery before any promotion |
| Low LTV, churned | 2 | Single email only; suppress if no response |
