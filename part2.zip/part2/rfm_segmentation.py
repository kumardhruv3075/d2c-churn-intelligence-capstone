"""
Part 2: RFM Segmentation & Retention Strategy
D2C Personal-Care Brand – Customer Churn Intelligence
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import warnings, os
warnings.filterwarnings("ignore")

plt.rcParams.update({"figure.dpi": 110, "axes.spines.top": False,
                     "axes.spines.right": False, "font.size": 11})
PALETTE = sns.color_palette("Set2")
DATA_DIR = "../data"
OUT_DIR  = "charts"
os.makedirs(OUT_DIR, exist_ok=True)

SNAPSHOT = pd.Timestamp("2024-06-30")

# ─── LOAD DATA ────────────────────────────────────────────────────────────────
customers = pd.read_csv(f"{DATA_DIR}/customers.csv", parse_dates=["join_date"])
orders    = pd.read_csv(f"{DATA_DIR}/orders.csv",    parse_dates=["order_date"])
tickets   = pd.read_csv(f"{DATA_DIR}/support_tickets.csv", parse_dates=["ticket_date"])
events    = pd.read_csv(f"{DATA_DIR}/web_app_events.csv",  parse_dates=["event_date"])
campaigns = pd.read_csv(f"{DATA_DIR}/campaigns.csv", parse_dates=["campaign_date"])
churn     = pd.read_csv(f"{DATA_DIR}/churn_labels.csv")

# ─── STEP 1: RFM FEATURES ─────────────────────────────────────────────────────
rfm = orders.groupby("customer_id").agg(
    last_order_date=("order_date", "max"),
    frequency=("order_id", "count"),
    monetary=("net_amount", "sum"),
).reset_index()
rfm["recency"] = (SNAPSHOT - rfm["last_order_date"]).dt.days
rfm = rfm.drop("last_order_date", axis=1)

# Customers with no orders get worst recency
all_cids = customers["customer_id"].tolist()
missing = set(all_cids) - set(rfm["customer_id"])
if missing:
    missing_df = pd.DataFrame({"customer_id": list(missing),
                                "frequency": 0, "monetary": 0, "recency": 999})
    rfm = pd.concat([rfm, missing_df], ignore_index=True)

# ─── RFM SCORING (1-5) ────────────────────────────────────────────────────────
def quartile_score(series, ascending=True):
    """Score 1-5 based on quartiles; ascending=True means low value → low score"""
    labels = [1,2,3,4,5] if ascending else [5,4,3,2,1]
    try:
        return pd.qcut(series, q=5, labels=labels, duplicates="drop").astype(int)
    except ValueError:
        return pd.cut(series, bins=5, labels=labels, duplicates="drop").astype(int)

rfm["R_score"] = quartile_score(rfm["recency"], ascending=False)   # low recency → high R
rfm["F_score"] = quartile_score(rfm["frequency"], ascending=False)
rfm["M_score"] = quartile_score(rfm["monetary"], ascending=False)
rfm["RFM_score"] = rfm["R_score"] + rfm["F_score"] + rfm["M_score"]

print("RFM Score Distribution:")
print(rfm["RFM_score"].describe().round(2))

# ─── STEP 2: ADDITIONAL BEHAVIOURAL SIGNALS ───────────────────────────────────

# 2a. Support ticket signal
ticket_agg = tickets.groupby("customer_id").agg(
    n_tickets=("ticket_id", "count"),
    n_negative=("sentiment", lambda x: (x.isin(["Negative","Very Negative"])).sum()),
    n_unresolved=("resolved", lambda x: (~x).sum()),
    n_escalated=("escalated", "sum"),
).reset_index()

# 2b. Return rate
return_rate = orders.groupby("customer_id").agg(
    return_rate=("is_returned", "mean"),
    avg_discount=("discount_pct", "mean"),
    n_categories=("category", "nunique"),
).reset_index()

# 2c. Campaign engagement
camp_agg = campaigns.groupby("customer_id").agg(
    n_campaigns=("campaign_type", "count"),
    n_opened=("opened", "sum"),
    n_converted=("converted", "sum"),
).reset_index()
camp_agg["open_rate"] = (camp_agg["n_opened"] / camp_agg["n_campaigns"]).round(3)

# 2d. Recent web/app activity (last 30 days before snapshot)
recent_events = events[events["event_date"] >= SNAPSHOT - pd.Timedelta(days=30)]
activity = recent_events.groupby("customer_id").agg(
    events_last30d=("event_type", "count"),
).reset_index()

# ─── MERGE ALL SIGNALS ────────────────────────────────────────────────────────
df = rfm.merge(customers[["customer_id","membership_tier","join_date","age","city"]], on="customer_id", how="left")
df = df.merge(ticket_agg, on="customer_id", how="left")
df = df.merge(return_rate, on="customer_id", how="left")
df = df.merge(camp_agg[["customer_id","n_campaigns","open_rate","n_converted"]], on="customer_id", how="left")
df = df.merge(activity, on="customer_id", how="left")
df = df.merge(churn[["customer_id","churned"]], on="customer_id", how="left")

# Fill NaN for customers with no tickets/events
df[["n_tickets","n_negative","n_unresolved","n_escalated"]] = \
    df[["n_tickets","n_negative","n_unresolved","n_escalated"]].fillna(0)
df[["events_last30d"]] = df[["events_last30d"]].fillna(0)
df[["open_rate","n_campaigns","n_converted"]] = \
    df[["open_rate","n_campaigns","n_converted"]].fillna(0)
df["return_rate"]  = df["return_rate"].fillna(0)
df["avg_discount"] = df["avg_discount"].fillna(0)
df["n_categories"] = df["n_categories"].fillna(0)

df["days_since_join"] = (SNAPSHOT - df["join_date"]).dt.days

# ─── STEP 3: SEGMENTATION LOGIC ───────────────────────────────────────────────
def assign_segment(row):
    r, f, m = row["R_score"], row["F_score"], row["M_score"]
    rfm_total = row["RFM_score"]
    tickets_neg = row["n_negative"]
    open_rate   = row["open_rate"]
    ret_rate    = row["return_rate"]
    disc        = row["avg_discount"]
    recency     = row["recency"]
    days_join   = row["days_since_join"]

    # Champions: very recent, high freq, high monetary
    if r >= 4 and f >= 4 and m >= 4:
        return "Champions"

    # Loyal Customers: consistent buyers, good RFM
    if f >= 4 and m >= 3 and r >= 3:
        return "Loyal Customers"

    # New Customers: joined recently, low frequency (not enough time)
    if days_join <= 90 and f <= 2:
        return "New Customers"

    # High-Value but Unhappy: high monetary but many negative tickets
    if m >= 4 and tickets_neg >= 2:
        return "High-Value Unhappy"

    # At-Risk Customers: were good, now dormant
    if r <= 2 and f >= 3:
        return "At-Risk"

    # Discount-Sensitive: heavy discount users, low loyalty
    if disc >= 0.12 and open_rate < 0.3:
        return "Discount-Sensitive"

    # Dormant: haven't bought in very long, low engagement
    if recency > 120 and f <= 2:
        return "Dormant"

    # Promising: recent but low frequency/monetary
    if r >= 3 and f <= 2:
        return "Promising"

    return "Needs Attention"

df["segment_name"] = df.apply(assign_segment, axis=1)
print("\nSegment Distribution:")
print(df["segment_name"].value_counts())

# ─── CHART 1: Segment Size ────────────────────────────────────────────────────
seg_counts = df["segment_name"].value_counts()
fig, ax = plt.subplots(figsize=(9, 5))
bars = ax.barh(seg_counts.index[::-1], seg_counts.values[::-1], color=PALETTE, edgecolor="white")
for b in bars:
    ax.text(b.get_width()+10, b.get_y()+b.get_height()/2,
            str(int(b.get_width())), va="center", fontweight="bold")
ax.set_title("RFM Segment Distribution", fontweight="bold")
ax.set_xlabel("Number of Customers")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/rfm_segment_distribution.png")
plt.close()

# ─── CHART 2: Churn Rate per Segment ─────────────────────────────────────────
seg_churn = df.groupby("segment_name")["churned"].mean().sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(9, 5))
colors = [PALETTE[3] if v > 0.7 else PALETTE[2] if v < 0.4 else PALETTE[1] for v in seg_churn.values]
bars = ax.barh(seg_churn.index[::-1], seg_churn.values[::-1]*100, color=colors[::-1], edgecolor="white")
for b in bars:
    ax.text(b.get_width()+0.5, b.get_y()+b.get_height()/2,
            f"{b.get_width():.1f}%", va="center", fontweight="bold")
ax.set_title("Churn Rate by RFM Segment", fontweight="bold")
ax.set_xlabel("Churn Rate (%)")
ax.xaxis.set_major_formatter(mticker.PercentFormatter())
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/rfm_churn_by_segment.png")
plt.close()

# ─── CHART 3: RFM Heatmap (R vs F, coloured by M) ───────────────────────────
heatmap_data = df.groupby(["R_score","F_score"])["monetary"].mean().unstack()
fig, ax = plt.subplots(figsize=(7, 5))
sns.heatmap(heatmap_data, annot=True, fmt=".0f", cmap="YlOrRd", ax=ax,
            linewidths=0.5, cbar_kws={"label": "Avg Monetary (₹)"})
ax.set_title("Avg Monetary Value: Recency Score × Frequency Score", fontweight="bold")
ax.set_xlabel("Frequency Score (5=High)")
ax.set_ylabel("Recency Score (5=Recent)")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/rfm_heatmap.png")
plt.close()

# ─── CHART 4: Segment Box Plot – Recency ────────────────────────────────────
order = seg_counts.index.tolist()
fig, ax = plt.subplots(figsize=(10, 5))
df.boxplot(column="recency", by="segment_name", ax=ax,
           boxprops=dict(color=PALETTE[0]), medianprops=dict(color="red", linewidth=2))
plt.suptitle("")
ax.set_title("Recency Distribution by Segment", fontweight="bold")
ax.set_xlabel("")
ax.set_ylabel("Days Since Last Order")
plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/rfm_recency_by_segment.png")
plt.close()

# ─── SAVE segments.csv ────────────────────────────────────────────────────────
seg_cols = ["customer_id","segment_name","recency","frequency","monetary",
            "R_score","F_score","M_score","RFM_score",
            "n_tickets","n_negative","n_unresolved","return_rate",
            "avg_discount","events_last30d","open_rate","membership_tier","churned"]
segments_out = df[seg_cols].copy()
segments_out.to_csv("segments.csv", index=False)
print(f"\nSegments saved: segments.csv ({len(segments_out)} rows)")

# ─── PRINT SEGMENT SUMMARY ────────────────────────────────────────────────────
summary = df.groupby("segment_name").agg(
    count=("customer_id","count"),
    churn_rate=("churned","mean"),
    avg_recency=("recency","mean"),
    avg_frequency=("frequency","mean"),
    avg_monetary=("monetary","mean"),
    avg_tickets=("n_tickets","mean"),
    avg_open_rate=("open_rate","mean"),
).round(2)
print("\n=== SEGMENT SUMMARY TABLE ===")
print(summary.to_string())

# ─── MANUAL REVIEW CASES ─────────────────────────────────────────────────────
print("\n=== MANUAL REVIEW CANDIDATES ===")
# Find edge cases: good RFM but high tickets, or bad RFM but recent purchase, etc.
edge1 = df[(df["M_score"]>=4) & (df["n_tickets"]>=2) & (df["churned"]==0)].head(3)[["customer_id","segment_name","recency","frequency","monetary","n_tickets","n_negative"]]
edge2 = df[(df["R_score"]>=4) & (df["churned"]==1) & (df["avg_discount"]>=0.15)].head(3)[["customer_id","segment_name","recency","frequency","monetary","avg_discount","churned"]]
edge3 = df[(df["frequency"]>=5) & (df["recency"]>90) & (df["churned"]==1)].head(4)[["customer_id","segment_name","recency","frequency","monetary","churned"]]
manual_ids = pd.concat([edge1, edge2, edge3]).drop_duplicates("customer_id").head(10)
print(manual_ids.to_string())
