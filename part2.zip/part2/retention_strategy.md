# Retention Strategy by RFM Segment
## D2C Personal-Care Brand – Part 2

**Snapshot Date:** 2024-06-30 | **Total Customers:** 3,000

---

## Segmentation Overview

| Segment | Count | Churn Rate | Avg Recency (days) | Avg Orders | Avg Spend (₹) | Avg Tickets | Campaign Open Rate |
|---|---|---|---|---|---|---|---|
| At-Risk | 1,131 | 95% | 280 | 2.4 | ₹7,984 | 0.85 | 39% |
| Champions | 293 | 67% | 26 | 1.7 | ₹3,861 | 1.08 | 39% |
| Loyal Customers | 588 | 72% | 58 | 2.5 | ₹6,924 | 1.00 | 39% |
| Needs Attention | 853 | 51% | 37 | 5.6 | ₹19,917 | 0.78 | 40% |
| High-Value Unhappy | 62 | 90% | 375 | 1.3 | ₹3,475 | 3.10 | 34% |
| Discount-Sensitive | 17 | 59% | 38 | 4.8 | ₹17,150 | 0.76 | 3% |
| Dormant | 4 | 100% | 185 | 12.3 | ₹44,017 | 0.75 | 40% |
| Promising | 46 | 37% | 28 | 12.4 | ₹39,121 | 0.43 | 37% |
| New Customers | 6 | 0% | 3 | 11.8 | ₹38,196 | 0.67 | 50% |

---

## Segment Profiles & Retention Actions

---

### 1. Champions (293 customers | 67% churn)

**Profile:** Most recently active customers (avg 26 days recency). Low order count but high recency scores. Likely newer high-intent buyers who purchased recently but haven't repeated yet.

**Non-RFM signals:** Moderate ticket count, average campaign engagement.

**Risk:** Despite recent activity, their low frequency means one bad experience or a competitor offer could cause them to leave.

**Retention Action:**
- Send a personalized "Thank You" package or loyalty reward within 14 days of their last purchase
- Offer early access to new product launches
- Enrol them in a "Champion Streak" loyalty challenge: 3 purchases in 90 days = Silver upgrade
- Goal: Drive a second/third purchase before the 60-day window closes

**Expected Business Value:** Converting 30% of Champions to repeat buyers adds ~88 customers with avg spend ₹3,861 → **₹340,000+ in recovered revenue**

---

### 2. Loyal Customers (588 customers | 72% churn)

**Profile:** Moderate recency (58 days), consistent purchasing, reasonable spend. These customers have demonstrated repeat behaviour but are drifting.

**Non-RFM signals:** Average ticket count, normal campaign engagement.

**Risk:** At 58-day average recency, many are approaching the 60-day churn window. Without a trigger, they will quietly lapse.

**Retention Action:**
- Trigger an automated "We miss you" message at Day 45 of inactivity
- Offer a loyalty point bonus for next purchase (not a discount — protect margins)
- Highlight subscription/auto-replenish options for consumable products (skincare, oral care)
- Personalize recommendations based on their past category purchases

**Expected Business Value:** Retaining 25% of Loyal Customers → 147 customers × ₹6,924 avg spend → **₹1.0M+ in recovered spend**

---

### 3. Needs Attention (853 customers | 51% churn)

**Profile:** Highest frequency buyers (avg 5.6 orders) and highest average monetary (₹19,917) in the dataset. Recent activity (37 days). These are your most valuable customers by spend — yet 51% are churning.

**Non-RFM signals:** Good campaign engagement (40% open rate), few tickets.

**Risk:** These are high-CLV customers. Losing them to a competitor would be the most costly churn scenario.

**Retention Action:**
- **Highest priority for retention budget** — these are the most valuable customers at risk
- Offer exclusive Gold/Platinum tier upgrade opportunities
- Assign a dedicated customer success touchpoint (chat or call) for top 200 by spend
- Create a VIP early-access program with sneak peeks, beta product trials, or personal consultations
- Introduce a "habit loop" subscription for their most-purchased categories

**Expected Business Value:** Retaining 20% of this segment → 170 customers × ₹19,917 → **₹3.4M in recovered high-value spend**

---

### 4. At-Risk (1,131 customers | 95% churn)

**Profile:** Very long time since last order (280 days avg). Low-to-moderate spend. These customers have already largely lapsed.

**Non-RFM signals:** Moderate tickets, average campaign open rate.

**Risk:** With 95% churn rate, most have already churned. Mass discounting here is the worst ROI use of budget.

**Retention Action:**
- Do NOT send blanket discount campaigns to this group — they are largely gone
- Run a low-cost winback email series (3 messages over 30 days) for those with recency 90–180 days
- For recency > 180 days: move to a long-dormant suppression list; attempt one final "We've missed you — here's why we're better now" message
- Measure response rate before committing more budget

**Expected Business Value:** 5% recovery rate = 57 customers returned × ₹7,984 → **₹455,000** but at very low campaign cost (email only)

---

### 5. High-Value Unhappy (62 customers | 90% churn)

**Profile:** High monetary potential but an average of 3.1 negative support tickets each. Long recency (375 days) — most have already disengaged after bad experiences.

**Non-RFM signals:** Highest ticket count of any segment; lowest campaign open rate.

**Risk:** These customers had potential but were let down by product or service. They are actively negative about the brand.

**Retention Action:**
- Personal outreach from a senior customer success representative — not an automated email
- Acknowledge specific issues from their ticket history
- Offer a genuine service recovery gesture (replacement, credit, or free shipping on next order)
- If ticket involves a product quality issue, loop in QA team

**Expected Business Value:** Saving 30% of this group = 19 customers — but also critical for preventing negative word-of-mouth and bad reviews

---

### 6. Discount-Sensitive (17 customers | 59% churn)

**Profile:** Heavy discount users (low campaign open rate of just 3% — they ignore messages but buy on promotions). Moderate-to-good spend.

**Non-RFM signals:** Near-zero campaign open rate suggests they only respond to promotions, not messaging.

**Retention Action:**
- Test non-discount offers: free sample with next order, product bundles, or subscription plans
- Do NOT increase discount depth — this reinforces price-sensitivity and erodes margin
- Introduce a "earn loyalty points" mechanic to shift them from discount-seeking to loyalty-building

---

### 7. Promising (46 customers | 37% churn)

**Profile:** Recent buyers (28 days recency), high frequency and monetary — but only 37% churn. These are your most naturally retained, high-potential customers.

**Action:** Nurture with product education, reviews requests, referral program invitations. Low intervention needed — avoid over-messaging.

---

### 8. New Customers (6 customers | 0% churn so far)

**Action:** Onboarding flow, welcome email series, first-order follow-up. Too early to assess churn risk.

---

## Campaign Budget Prioritization

**Total Budget Assumption: ₹500,000**

| Priority | Segment | Allocation | Rationale |
|---|---|---|---|
| 🥇 1 | Needs Attention | ₹200,000 (40%) | Highest CLV at risk; retention ROI is greatest |
| 🥈 2 | Loyal Customers | ₹120,000 (24%) | Large segment, recoverable at moderate cost |
| 🥉 3 | High-Value Unhappy | ₹80,000 (16%) | Personal recovery; prevents negative NPS |
| 4 | Champions | ₹60,000 (12%) | Low-cost engagement, high conversion potential |
| 5 | At-Risk (90–180d only) | ₹30,000 (6%) | Email-only winback for marginal recovery |
| 6 | Discount-Sensitive | ₹10,000 (2%) | Test non-discount mechanic only |

**Do NOT allocate budget to:** At-Risk customers with recency > 180 days, or blanket SMS to all 3,000 customers.

---

## Non-RFM Signals Used

1. **Support Ticket Count & Sentiment** — Negative ticket volume identifies unhappy customers irrespective of spend level
2. **Campaign Open Rate** — Disengaged non-openers (especially Discount-Sensitive) need channel-switch or mechanic change
3. **Return Rate** — High return rate signals product dissatisfaction independent of order count
4. **Avg Discount % Used** — Identifies discount-dependent buyers who are not true loyalists
5. **Events in Last 30 Days** — Recent digital engagement predicts continued interest even if no purchase
