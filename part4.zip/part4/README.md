# Part 4 — FastAPI Churn Scoring Service
## D2C Customer Churn Intelligence

### Overview
A production-ready internal REST API that serves churn-risk predictions from a trained Gradient Boosting model. The service accepts customer feature payloads from a CRM system and returns churn probability, predicted class, risk level, and a human-readable explanation.

---

### Repository Structure

```
part4/
├── README.md                ← This file
├── app/
│   ├── main.py              ← FastAPI application (endpoints, models, scoring logic)
│   └── __init__.py
├── tests/
│   └── test_api.py          ← 17 API test cases (all passing)
├── model.pkl                ← Pre-trained GradientBoostingClassifier pipeline
├── train_model.py           ← Script to retrain & save model from scratch
├── monitoring_plan.md       ← Post-deployment monitoring & responsible-use guide
├── Dockerfile               ← Docker setup for containerized deployment
├── requirements.txt         ← Python dependencies
└── metrics.json             ← Model performance metrics
```

---

### Setup & Run

#### Option 1: Local (direct)

```bash
# Install dependencies
pip install -r requirements.txt

# (Optional) Retrain model from raw data
python train_model.py

# Start the API
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

API will be available at: `http://localhost:8000`  
Interactive docs: `http://localhost:8000/docs`

#### Option 2: Docker

```bash
# Build
docker build -t d2c-churn-api .

# Run
docker run -p 8000:8000 d2c-churn-api

# With custom model path
docker run -p 8000:8000 -e MODEL_PATH=/app/model.pkl d2c-churn-api
```

#### Run Tests

```bash
pytest tests/test_api.py -v
# or
python tests/test_api.py
```

---

### Endpoints

#### `GET /health`
Health check — confirms API is running and model is loaded.

**Response:**
```json
{
  "status": "ok",
  "model_loaded": true,
  "model_path": "model.pkl",
  "api_version": "1.0.0",
  "threshold": 0.45
}
```

---

#### `POST /predict`
Score a single customer for churn risk.

**Sample Request:**
```json
{
  "customer_id": "C00042",
  "recency_days": 85,
  "order_frequency": 3,
  "total_monetary": 8500.0,
  "avg_order_value": 2833.0,
  "return_rate": 0.1,
  "avg_discount_pct": 0.05,
  "n_categories_purchased": 2,
  "days_since_join": 420,
  "n_support_tickets": 1,
  "n_negative_tickets": 0,
  "n_unresolved_tickets": 0,
  "n_web_events": 22,
  "n_events_last30d": 3,
  "n_campaigns_sent": 5,
  "n_campaigns_opened": 2,
  "n_campaigns_converted": 0,
  "gender": "F",
  "city": "Bangalore",
  "membership_tier": "Silver",
  "acquisition_channel": "Instagram"
}
```

**Sample Response:**
```json
{
  "customer_id": "C00042",
  "churn_probability": 0.6231,
  "predicted_class": 1,
  "risk_level": "medium",
  "risk_explanation": "Medium churn risk (62% probability). Key signals: no purchase in 85 days; multiple moderate risk signals detected.",
  "threshold_used": 0.45
}
```

---

#### `POST /batch_predict`
Score multiple customers in one request (max 500).

**Sample Request:**
```json
{
  "customers": [
    { ...customer_1_payload... },
    { ...customer_2_payload... }
  ]
}
```

**Sample Response:**
```json
{
  "predictions": [
    {
      "customer_id": "C00001",
      "churn_probability": 0.12,
      "predicted_class": 0,
      "risk_level": "very_low",
      "risk_explanation": "Very_low churn risk (12% probability)...",
      "threshold_used": 0.45
    },
    {
      "customer_id": "C00002",
      "churn_probability": 0.87,
      "predicted_class": 1,
      "risk_level": "high",
      "risk_explanation": "High churn risk (87% probability). Key signals: no purchase in 210 days; Bronze membership tier...",
      "threshold_used": 0.45
    }
  ],
  "total": 2,
  "high_risk_count": 1
}
```

---

### Input Validation

All inputs are validated by Pydantic. Common errors:

| Validation | HTTP Status |
|---|---|
| Invalid `membership_tier` (not Bronze/Silver/Gold/Platinum) | 422 |
| `recency_days < 0` | 422 |
| `return_rate > 1.0` | 422 |
| `n_negative_tickets > n_support_tickets` | 422 |
| `n_campaigns_opened > n_campaigns_sent` | 422 |
| Missing required field | 422 |
| Empty batch list | 400 |
| Batch size > 500 | 400 |

---

### Risk Levels

| Level | Probability Range | Recommended Action |
|---|---|---|
| `very_low` | < 0.30 | No action needed |
| `low` | 0.30 – 0.50 | Monitor; add to loyalty nurture |
| `medium` | 0.50 – 0.75 | Send personalized retention message |
| `high` | ≥ 0.75 | Priority outreach; assign to retention specialist |

---

### Model Notes

- **Algorithm:** GradientBoostingClassifier (scikit-learn)
- **Decision threshold:** 0.45 (recall-optimized for churn)
- **Test performance:** Recall 90.7% | Precision 82.1% | ROC-AUC 81.6%
- **Retrain:** Run `python train_model.py` with updated data in `../data/`
- **Model format:** joblib-serialized sklearn Pipeline (`model.pkl`)

---

### Environment Variables

| Variable | Default | Description |
|---|---|---|
| `MODEL_PATH` | `model.pkl` | Path to the trained model file |
| `DATA_DIR` | `../data` | Path to data directory (for `train_model.py`) |

---

### Responsible Use

See [monitoring_plan.md](monitoring_plan.md) for the full responsible-use policy.

**Quick summary:**
- ✅ Use scores to prioritize retention outreach
- ✅ Combine with human judgment for high-LTV customers
- ❌ Do not reduce service quality based on churn score
- ❌ Do not use as sole basis for irreversible decisions
- ❌ Do not share individual scores with customers
