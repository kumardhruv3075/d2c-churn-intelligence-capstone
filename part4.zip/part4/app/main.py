"""
Part 4: FastAPI Churn Scoring Service
D2C Personal-Care Brand – Customer Churn Intelligence
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, field_validator
from typing import List, Optional, Literal
import joblib
import numpy as np
import pandas as pd
import os
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─── LOAD MODEL ───────────────────────────────────────────────────────────────
MODEL_PATH = os.getenv("MODEL_PATH", "model.pkl")

try:
    model = joblib.load(MODEL_PATH)
    logger.info(f"Model loaded successfully from {MODEL_PATH}")
except FileNotFoundError:
    logger.error(f"Model file not found at {MODEL_PATH}. Run train_model.py first.")
    model = None

app = FastAPI(
    title="D2C Customer Churn Scoring API",
    description=(
        "Internal CRM churn-risk scoring service for the D2C personal-care brand. "
        "Returns churn probability, predicted class, risk level, and a human-readable explanation. "
        "Use outputs to prioritize retention interventions — not to deny customers service."
    ),
    version="1.0.0",
    contact={"name": "Analytics Team"},
)

# ─── CONSTANTS ────────────────────────────────────────────────────────────────
THRESHOLD = 0.45

FEATURE_COLUMNS = [
    # numeric
    "recency_days", "log_recency", "order_frequency", "total_monetary",
    "log_monetary", "avg_order_value", "monetary_per_order",
    "return_rate", "avg_discount_pct", "n_categories_purchased",
    "n_support_tickets", "n_negative_tickets", "negative_ticket_rate",
    "n_unresolved_tickets", "n_web_events", "n_events_last30d",
    "events_per_day", "n_campaigns_sent", "n_campaigns_opened",
    "campaign_open_rate", "campaign_conv_rate", "days_since_join",
    # categorical
    "gender", "city", "membership_tier", "acquisition_channel",
]

VALID_TIERS    = {"Bronze", "Silver", "Gold", "Platinum"}
VALID_GENDERS  = {"M", "F", "Other"}
VALID_CHANNELS = {"Instagram", "Google", "Referral", "Influencer", "TV", "Email"}


# ─── REQUEST / RESPONSE MODELS ────────────────────────────────────────────────
class CustomerFeatures(BaseModel):
    customer_id: Optional[str] = Field(None, description="Customer identifier (for logging/tracking)")

    # Core behavioral features
    recency_days: int = Field(..., ge=0, le=9999, description="Days since last order")
    order_frequency: int = Field(..., ge=0, description="Total number of orders")
    total_monetary: float = Field(..., ge=0, description="Total net spend in INR")
    avg_order_value: float = Field(..., ge=0, description="Average net order value in INR")
    return_rate: float = Field(..., ge=0.0, le=1.0, description="Proportion of orders returned")
    avg_discount_pct: float = Field(..., ge=0.0, le=1.0, description="Average discount fraction (0.10 = 10%)")
    n_categories_purchased: int = Field(..., ge=0, description="Number of distinct product categories purchased")
    days_since_join: int = Field(..., ge=0, description="Customer tenure in days")

    # Support signals
    n_support_tickets: int = Field(..., ge=0, description="Total support tickets raised")
    n_negative_tickets: int = Field(..., ge=0, description="Support tickets with Negative/Very Negative sentiment")
    n_unresolved_tickets: int = Field(..., ge=0, description="Support tickets still unresolved")

    # Digital activity
    n_web_events: int = Field(..., ge=0, description="Total web/app engagement events")
    n_events_last30d: int = Field(..., ge=0, description="Web/app events in last 30 days")

    # Campaign engagement
    n_campaigns_sent: int = Field(..., ge=0, description="Number of campaigns sent to customer")
    n_campaigns_opened: int = Field(..., ge=0, description="Number of campaigns opened")
    n_campaigns_converted: int = Field(0, ge=0, description="Number of campaigns converted (optional)")

    # Demographics/profile
    gender: Literal["M", "F", "Other"] = Field("M", description="Customer gender")
    city: str = Field("Mumbai", description="Customer city")
    membership_tier: Literal["Bronze", "Silver", "Gold", "Platinum"] = Field(
        "Bronze", description="Membership tier")
    acquisition_channel: str = Field("Instagram", description="Acquisition channel")

    @field_validator("n_negative_tickets")
    @classmethod
    def negative_le_total(cls, v, info):
        if "n_support_tickets" in info.data and v > info.data["n_support_tickets"]:
            raise ValueError("n_negative_tickets cannot exceed n_support_tickets")
        return v

    @field_validator("n_campaigns_opened")
    @classmethod
    def opened_le_sent(cls, v, info):
        if "n_campaigns_sent" in info.data and v > info.data["n_campaigns_sent"]:
            raise ValueError("n_campaigns_opened cannot exceed n_campaigns_sent")
        return v

    model_config = {"json_schema_extra": {
        "example": {
            "customer_id": "C00042",
            "recency_days": 85,
            "order_frequency": 3,
            "total_monetary": 8500.0,
            "avg_order_value": 2833.0,
            "return_rate": 0.1,
            "avg_discount_pct": 0.05,
            "n_categories_purchased": 2,
            "days_since_join": 420,
            "n_support_tickets": 1,
            "n_negative_tickets": 0,
            "n_unresolved_tickets": 0,
            "n_web_events": 22,
            "n_events_last30d": 3,
            "n_campaigns_sent": 5,
            "n_campaigns_opened": 2,
            "gender": "F",
            "city": "Bangalore",
            "membership_tier": "Silver",
            "acquisition_channel": "Instagram"
        }
    }}


class PredictionResponse(BaseModel):
    customer_id: Optional[str]
    churn_probability: float
    predicted_class: int
    risk_level: str
    risk_explanation: str
    threshold_used: float


class BatchRequest(BaseModel):
    customers: List[CustomerFeatures]


class BatchResponse(BaseModel):
    predictions: List[PredictionResponse]
    total: int
    high_risk_count: int


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    model_path: str
    api_version: str
    threshold: float


# ─── HELPERS ──────────────────────────────────────────────────────────────────
def derive_features(c: CustomerFeatures) -> pd.DataFrame:
    """Add derived features from raw inputs and return a DataFrame for the model."""
    monetary_per_order  = c.total_monetary / (c.order_frequency + 1)
    negative_ticket_rate = c.n_negative_tickets / (c.n_support_tickets + 1)
    campaign_open_rate  = c.n_campaigns_opened / (c.n_campaigns_sent + 1)
    campaign_conv_rate  = c.n_campaigns_converted / (c.n_campaigns_sent + 1)
    events_per_day      = c.n_web_events / (c.days_since_join + 1)
    log_recency         = np.log1p(c.recency_days)
    log_monetary        = np.log1p(c.total_monetary)

    row = {
        "recency_days":          c.recency_days,
        "log_recency":           log_recency,
        "order_frequency":       c.order_frequency,
        "total_monetary":        c.total_monetary,
        "log_monetary":          log_monetary,
        "avg_order_value":       c.avg_order_value,
        "monetary_per_order":    monetary_per_order,
        "return_rate":           c.return_rate,
        "avg_discount_pct":      c.avg_discount_pct,
        "n_categories_purchased": c.n_categories_purchased,
        "n_support_tickets":     c.n_support_tickets,
        "n_negative_tickets":    c.n_negative_tickets,
        "negative_ticket_rate":  negative_ticket_rate,
        "n_unresolved_tickets":  c.n_unresolved_tickets,
        "n_web_events":          c.n_web_events,
        "n_events_last30d":      c.n_events_last30d,
        "events_per_day":        events_per_day,
        "n_campaigns_sent":      c.n_campaigns_sent,
        "n_campaigns_opened":    c.n_campaigns_opened,
        "campaign_open_rate":    campaign_open_rate,
        "campaign_conv_rate":    campaign_conv_rate,
        "days_since_join":       c.days_since_join,
        "gender":                c.gender,
        "city":                  c.city,
        "membership_tier":       c.membership_tier,
        "acquisition_channel":   c.acquisition_channel,
    }
    return pd.DataFrame([row])


def get_risk_level(prob: float) -> str:
    if prob >= 0.75:
        return "high"
    elif prob >= 0.50:
        return "medium"
    elif prob >= 0.30:
        return "low"
    return "very_low"


def build_explanation(c: CustomerFeatures, prob: float, risk: str) -> str:
    reasons = []
    camp_open_rate = c.n_campaigns_opened / (c.n_campaigns_sent + 1)
    if c.recency_days > 60:
        reasons.append(f"no purchase in {c.recency_days} days")
    if c.membership_tier == "Bronze":
        reasons.append("Bronze membership tier")
    if c.n_negative_tickets >= 2:
        reasons.append(f"{c.n_negative_tickets} negative support tickets")
    if c.n_unresolved_tickets >= 1:
        reasons.append(f"{c.n_unresolved_tickets} unresolved ticket(s)")
    if c.n_events_last30d == 0:
        reasons.append("no digital activity in last 30 days")
    if c.avg_discount_pct > 0.15:
        reasons.append("high discount dependency")
    if camp_open_rate == 0 and c.n_campaigns_sent > 0:
        reasons.append("never opened a campaign message")

    if not reasons:
        if risk in ("high", "medium"):
            reasons.append("multiple moderate risk signals detected")
        else:
            reasons.append("low recency and healthy engagement")

    reason_str = "; ".join(reasons[:3])
    return (f"{risk.capitalize()} churn risk ({prob:.0%} probability). "
            f"Key signals: {reason_str}.")


def score_customer(c: CustomerFeatures) -> PredictionResponse:
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded. Run train_model.py first.")
    X = derive_features(c)
    prob = float(model.predict_proba(X)[0, 1])
    pred = int(prob >= THRESHOLD)
    risk = get_risk_level(prob)
    explanation = build_explanation(c, prob, risk)
    return PredictionResponse(
        customer_id=c.customer_id,
        churn_probability=round(prob, 4),
        predicted_class=pred,
        risk_level=risk,
        risk_explanation=explanation,
        threshold_used=THRESHOLD,
    )


# ─── ENDPOINTS ────────────────────────────────────────────────────────────────
@app.get("/health", response_model=HealthResponse, tags=["System"])
def health_check():
    """Health check endpoint — confirms API is running and model is loaded."""
    return HealthResponse(
        status="ok",
        model_loaded=(model is not None),
        model_path=MODEL_PATH,
        api_version="1.0.0",
        threshold=THRESHOLD,
    )


@app.post("/predict", response_model=PredictionResponse, tags=["Prediction"])
def predict(customer: CustomerFeatures):
    """
    Score a single customer for churn risk.

    Returns churn probability (0–1), predicted class (0=Retained, 1=Churned),
    risk level (very_low / low / medium / high), and a human-readable explanation.
    """
    return score_customer(customer)


@app.post("/batch_predict", response_model=BatchResponse, tags=["Prediction"])
def batch_predict(batch: BatchRequest):
    """
    Score multiple customers for churn risk in a single request.

    Accepts a list of customer feature objects. Returns predictions for each,
    plus a summary count of high-risk customers.
    """
    if len(batch.customers) == 0:
        raise HTTPException(status_code=400, detail="Customer list is empty.")
    if len(batch.customers) > 500:
        raise HTTPException(status_code=400, detail="Batch size exceeds limit of 500.")

    predictions = [score_customer(c) for c in batch.customers]
    high_risk = sum(1 for p in predictions if p.risk_level == "high")

    return BatchResponse(
        predictions=predictions,
        total=len(predictions),
        high_risk_count=high_risk,
    )
