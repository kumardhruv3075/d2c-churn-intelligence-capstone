# Monitoring & Responsible-Use Plan
## D2C Churn Scoring API — Post-Deployment

**Service:** `/predict` and `/batch_predict` endpoints  
**Model:** GradientBoostingClassifier v1.0  
**Deployment Owner:** Analytics Team  

---

## 1. What to Monitor After Deployment

### A. API Health & Reliability

| Metric | Tool | Alert Threshold | Action |
|---|---|---|---|
| API response time (p95) | Prometheus / Grafana | > 500ms | Scale horizontally |
| Error rate (4xx + 5xx) | Log aggregator | > 1% of requests | Page on-call engineer |
| Model load failures at startup | Startup log | Any failure | Auto-restart + alert |
| Uptime / availability | Uptime monitor | < 99.5% | SLA breach review |

**Sample alert rule (pseudocode):**
```
IF error_rate_5min > 0.01 AND request_volume > 10
THEN page(on_call_engineer, "Churn API error rate elevated")
```

---

### B. Prediction Distribution (Model Drift Detection)

Shift in the distribution of churn probabilities is an early warning sign of **data drift** (input features have changed) or **concept drift** (the relationship between features and churn has changed).

| Metric | Baseline | Alert | Frequency |
|---|---|---|---|
| Mean churn probability | ~0.72 (training) | ±0.08 shift | Weekly |
| % customers scored "high risk" | ~55% | ±10 pp shift | Weekly |
| % customers scored "very_low" | ~10% | ±5 pp shift | Weekly |
| Prediction entropy | Compute weekly baseline | 20% change | Weekly |

**Implementation:**
```python
# Log each week's scoring run
weekly_mean_prob = predictions_df["churn_probability"].mean()
if abs(weekly_mean_prob - BASELINE_MEAN) > 0.08:
    send_alert("Churn probability distribution shifted — model drift suspected")
```

---

### C. Feature Distribution Drift (Data Drift)

Track the **Population Stability Index (PSI)** for the top-5 features monthly:

| Feature | PSI Threshold | Action if Exceeded |
|---|---|---|
| `recency_days` | > 0.2 | Investigate CRM ordering pattern change |
| `order_frequency` | > 0.2 | Check for seasonal or product launch effects |
| `membership_tier` | > 0.15 | Check for tier policy change by business |
| `n_web_events` | > 0.2 | Investigate app/website changes |
| `avg_discount_pct` | > 0.15 | Check for major promotional change |

**PSI interpretation:**
- PSI < 0.10: No significant change
- 0.10 ≤ PSI < 0.20: Monitor closely
- PSI ≥ 0.20: Significant drift — trigger retraining review

---

### D. Business Outcome Validation

This is the most important check — did the model actually help retain customers?

| Metric | Measurement | Frequency |
|---|---|---|
| Actual churn rate (true label) vs predicted | Compare scored customers' actual behavior after 60 days | Monthly |
| Retention rate in "High Risk" segment | Track whether interventions reduced churn | Monthly |
| Revenue saved per ₹ spent on retention | Campaign ROI | Quarterly |
| False negative rate by tier (missed Platinum churners) | Manual audit of churned Platinum customers | Monthly |

**Cohort tracking setup:**
```
Every month:
  1. Score all active customers with /batch_predict
  2. Save (customer_id, churn_probability, risk_level, score_date)
  3. After 60 days, join with actual churn label
  4. Calculate precision, recall, F1 for that cohort
  5. Compare with training-time metrics (0.82 / 0.91 / 0.86)
```

---

### E. API Usage Patterns

| Metric | Purpose | Alert |
|---|---|---|
| Requests per endpoint per hour | Detect unusual traffic | Spike > 5× baseline |
| Batch size distribution | Detect misuse | Batch > 400 consistently |
| Unknown cities/channels in input | Detect data schema changes | > 5% unknown values |
| Response field null rates | Detect serialization bugs | Any null in required field |

---

## 2. Retraining Triggers

Retrain the model when **any** of the following occur:

| Trigger | Threshold | Priority |
|---|---|---|
| Monthly F1-score drop | Below 0.78 on validation set | 🔴 High — retrain within 2 weeks |
| Actual churn rate shift | ±8 pp from training rate (73.97%) | 🔴 High |
| Feature PSI breach | Any top-5 feature PSI > 0.20 | 🟡 Medium — retrain within 1 month |
| Time elapsed since last training | > 6 months | 🟡 Medium |
| Major business change | New tier, new category, pricing change | 🟡 Medium |
| Churn label definition change | Changed from 60-day to 90-day window | 🔴 High — full retrain required |

**Retraining process:**
1. Collect updated snapshot data (orders, tickets, events, campaigns) up to new snapshot date
2. Re-run `train_model.py` — no manual steps needed
3. Compare new model metrics with production model metrics on a held-out set
4. If new model is better on both F1 and PR-AUC → deploy as v1.1
5. Keep old model as fallback for 2 weeks post-deployment

---

## 3. Responsible-Use Guidelines

### What the Retention Team SHOULD Do

✅ **Use churn scores to prioritize outreach** — focus human attention and budget on customers predicted as "high" or "medium" risk  
✅ **Use risk_explanation to personalize messages** — a customer flagged for "no purchase in 120 days" should receive a different message than one flagged for "negative support tickets"  
✅ **Combine model output with human judgment** — for Platinum customers with high CLV, always have a human review before deciding on intervention type  
✅ **Track which interventions worked** — log campaign_id alongside churn score so you can measure per-segment ROI  
✅ **Escalate anomalies** — if the API returns an unusually high proportion of "very_low" scores on a given day, flag it to the analytics team  

---

### What the Retention Team SHOULD NOT Do

❌ **Do not use churn scores to reduce service quality** — a "high risk" customer must never receive worse support, slower responses, or fewer features because of their score  
❌ **Do not automatically deny loyalty program benefits** based on churn score — the model may be wrong (10% FN rate for high-value customers)  
❌ **Do not share individual churn scores externally** — these are internal risk signals, not data to be shared with the customer themselves  
❌ **Do not use a single churn score as a final decision** for high-spend customers (LTV > ₹20,000) — require human approval  
❌ **Do not forget the 31 false negatives** — some of the highest-value customers appear "safe" to the model but churn anyway. Always cross-check high-LTV accounts manually at month-end  
❌ **Do not run batch scoring on the same cohort daily** — weekly scoring is sufficient and prevents over-intervention fatigue  
❌ **Do not treat churn probability as certainty** — a score of 0.75 means "75% chance of churning given historical patterns", not a guaranteed outcome  

---

## 4. Responsible Use Summary for Leadership

> **The churn scoring API is a decision-support tool, not a decision-making tool.**
>
> It identifies *likely* churners based on past behavioral patterns. It does not explain *why* a customer wants to leave, and it cannot account for external factors (competitor promotions, life events, economic conditions). Every high-risk flag should be reviewed by a retention specialist before a significant budget is committed.
>
> The model's strongest use case is **triage at scale**: helping the team focus limited time and budget on the customers most likely to be recoverable, rather than treating all customers equally.

---

## 5. Incident Response

| Scenario | Response |
|---|---|
| API returns 503 on `/predict` | Check if `model.pkl` exists at `MODEL_PATH`; restart container |
| All customers score 0.0 or 1.0 | Model loaded incorrectly — redeploy from last known good image |
| Churn rate in production drops to < 50% | Likely a data pipeline issue — validate input feature distributions |
| Privacy breach concern | Immediately suspend API, notify Legal, audit logs |
