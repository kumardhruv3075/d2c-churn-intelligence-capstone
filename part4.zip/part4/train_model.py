"""
train_model.py — Train and save the churn model for the FastAPI service.
Run this before starting the API if model.pkl is not present.
"""

import pandas as pd
import numpy as np
import joblib, os, json

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import roc_auc_score, f1_score, recall_score, precision_score

DATA_DIR  = os.getenv("DATA_DIR", "../data")
MODEL_OUT = os.getenv("MODEL_PATH", "model.pkl")

print("Loading data...")
snapshot = pd.read_csv(f"{DATA_DIR}/modeling_snapshot.csv")
print(f"  Rows: {len(snapshot)} | Churn rate: {snapshot['churned'].mean():.2%}")

# ── FEATURES ──────────────────────────────────────────────────────────────────
df = snapshot.copy()
df["monetary_per_order"]   = df["total_monetary"] / (df["order_frequency"] + 1)
df["negative_ticket_rate"] = df["n_negative_tickets"] / (df["n_support_tickets"] + 1)
df["campaign_open_rate"]   = df["n_campaigns_opened"] / (df["n_campaigns_sent"] + 1)
df["campaign_conv_rate"]   = df["n_campaigns_converted"] / (df["n_campaigns_sent"] + 1)
df["events_per_day"]       = df["n_web_events"] / (df["days_since_join"] + 1)
df["log_recency"]          = np.log1p(df["recency_days"])
df["log_monetary"]         = np.log1p(df["total_monetary"])

NUM_FEATURES = [
    "recency_days","log_recency","order_frequency","total_monetary","log_monetary",
    "avg_order_value","monetary_per_order","return_rate","avg_discount_pct",
    "n_categories_purchased","n_support_tickets","n_negative_tickets",
    "negative_ticket_rate","n_unresolved_tickets","n_web_events","n_events_last30d",
    "events_per_day","n_campaigns_sent","n_campaigns_opened",
    "campaign_open_rate","campaign_conv_rate","days_since_join",
]
CAT_FEATURES = ["gender","city","membership_tier","acquisition_channel"]
ALL_FEATURES = NUM_FEATURES + CAT_FEATURES

X = df[ALL_FEATURES]
y = df["churned"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.15, random_state=42, stratify=y)

preprocessor = ColumnTransformer([
    ("num", StandardScaler(), NUM_FEATURES),
    ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), CAT_FEATURES),
])

pipe = Pipeline([
    ("pre", preprocessor),
    ("clf", GradientBoostingClassifier(
        n_estimators=150, learning_rate=0.05,
        max_depth=4, subsample=0.8, random_state=42
    )),
])

print("Training model...")
pipe.fit(X_train, y_train)

probs = pipe.predict_proba(X_test)[:,1]
preds = (probs >= 0.45).astype(int)
metrics = {
    "roc_auc":   round(roc_auc_score(y_test, probs), 4),
    "recall":    round(recall_score(y_test, preds), 4),
    "precision": round(precision_score(y_test, preds), 4),
    "f1":        round(f1_score(y_test, preds), 4),
}
print("Test metrics:", metrics)

joblib.dump(pipe, MODEL_OUT)
print(f"Model saved → {MODEL_OUT}")

with open("metrics.json","w") as f:
    json.dump(metrics, f, indent=2)
print("Metrics saved → metrics.json")
