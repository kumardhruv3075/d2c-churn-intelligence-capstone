"""
test_api.py — API test suite for the D2C Churn Scoring Service.

Usage:
  Start API first:  uvicorn app.main:app --reload
  Then run:         pytest tests/test_api.py -v
  Or standalone:    python tests/test_api.py
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

# ─── FIXTURES ─────────────────────────────────────────────────────────────────
LOW_RISK_CUSTOMER = {
    "customer_id": "C_TEST_LOW",
    "recency_days": 5,
    "order_frequency": 12,
    "total_monetary": 45000.0,
    "avg_order_value": 3750.0,
    "return_rate": 0.0,
    "avg_discount_pct": 0.05,
    "n_categories_purchased": 4,
    "days_since_join": 600,
    "n_support_tickets": 0,
    "n_negative_tickets": 0,
    "n_unresolved_tickets": 0,
    "n_web_events": 80,
    "n_events_last30d": 12,
    "n_campaigns_sent": 8,
    "n_campaigns_opened": 6,
    "n_campaigns_converted": 2,
    "gender": "F",
    "city": "Bangalore",
    "membership_tier": "Platinum",
    "acquisition_channel": "Referral",
}

HIGH_RISK_CUSTOMER = {
    "customer_id": "C_TEST_HIGH",
    "recency_days": 350,
    "order_frequency": 1,
    "total_monetary": 800.0,
    "avg_order_value": 800.0,
    "return_rate": 0.0,
    "avg_discount_pct": 0.20,
    "n_categories_purchased": 1,
    "days_since_join": 400,
    "n_support_tickets": 4,
    "n_negative_tickets": 3,
    "n_unresolved_tickets": 2,
    "n_web_events": 2,
    "n_events_last30d": 0,
    "n_campaigns_sent": 6,
    "n_campaigns_opened": 0,
    "n_campaigns_converted": 0,
    "gender": "M",
    "city": "Delhi",
    "membership_tier": "Bronze",
    "acquisition_channel": "Google",
}

MEDIUM_RISK_CUSTOMER = {
    "customer_id": "C_TEST_MED",
    "recency_days": 55,
    "order_frequency": 4,
    "total_monetary": 14000.0,
    "avg_order_value": 3500.0,
    "return_rate": 0.10,
    "avg_discount_pct": 0.08,
    "n_categories_purchased": 2,
    "days_since_join": 300,
    "n_support_tickets": 1,
    "n_negative_tickets": 1,
    "n_unresolved_tickets": 0,
    "n_web_events": 18,
    "n_events_last30d": 2,
    "n_campaigns_sent": 4,
    "n_campaigns_opened": 2,
    "n_campaigns_converted": 0,
    "gender": "F",
    "city": "Mumbai",
    "membership_tier": "Silver",
    "acquisition_channel": "Instagram",
}

# ─── TEST: HEALTH ──────────────────────────────────────────────────────────────
def test_health_returns_ok():
    """GET /health should return 200 and status='ok'"""
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert "model_loaded" in body
    assert "threshold" in body
    print(f"  ✓ /health → status=ok, model_loaded={body['model_loaded']}, threshold={body['threshold']}")

def test_health_contains_version():
    """GET /health should include api_version field"""
    response = client.get("/health")
    body = response.json()
    assert "api_version" in body
    assert body["api_version"] == "1.0.0"
    print(f"  ✓ /health → api_version={body['api_version']}")


# ─── TEST: PREDICT ─────────────────────────────────────────────────────────────
def test_predict_low_risk_customer():
    """POST /predict with Platinum customer → low churn probability"""
    response = client.post("/predict", json=LOW_RISK_CUSTOMER)
    assert response.status_code == 200
    body = response.json()
    assert "churn_probability" in body
    assert "predicted_class" in body
    assert "risk_level" in body
    assert "risk_explanation" in body
    assert 0.0 <= body["churn_probability"] <= 1.0
    assert body["predicted_class"] in [0, 1]
    # Platinum, recent, high-frequency → expect low probability
    assert body["churn_probability"] < 0.5, f"Expected low prob for Platinum customer, got {body['churn_probability']}"
    print(f"  ✓ Low-risk customer → prob={body['churn_probability']:.3f}, risk={body['risk_level']}")


def test_predict_high_risk_customer():
    """POST /predict with Bronze dormant customer → high churn probability"""
    response = client.post("/predict", json=HIGH_RISK_CUSTOMER)
    assert response.status_code == 200
    body = response.json()
    assert body["churn_probability"] > 0.5, f"Expected high prob for dormant Bronze, got {body['churn_probability']}"
    assert body["predicted_class"] == 1
    assert body["risk_level"] in ["medium","high"]
    print(f"  ✓ High-risk customer → prob={body['churn_probability']:.3f}, risk={body['risk_level']}")


def test_predict_returns_explanation():
    """POST /predict response must include a non-empty risk_explanation string"""
    response = client.post("/predict", json=MEDIUM_RISK_CUSTOMER)
    assert response.status_code == 200
    body = response.json()
    assert isinstance(body["risk_explanation"], str)
    assert len(body["risk_explanation"]) > 10
    print(f"  ✓ Explanation: '{body['risk_explanation'][:80]}...'")


def test_predict_threshold_field():
    """POST /predict response must echo back the threshold used"""
    response = client.post("/predict", json=MEDIUM_RISK_CUSTOMER)
    body = response.json()
    assert "threshold_used" in body
    assert body["threshold_used"] == 0.45
    print(f"  ✓ threshold_used={body['threshold_used']}")


def test_predict_optional_customer_id():
    """POST /predict with no customer_id should still succeed"""
    payload = {k: v for k, v in MEDIUM_RISK_CUSTOMER.items() if k != "customer_id"}
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    print("  ✓ /predict works without customer_id")


# ─── TEST: VALIDATION / ERROR HANDLING ────────────────────────────────────────
def test_predict_invalid_tier():
    """POST /predict with invalid membership_tier → 422 Unprocessable Entity"""
    bad = {**HIGH_RISK_CUSTOMER, "membership_tier": "Diamond"}
    response = client.post("/predict", json=bad)
    assert response.status_code == 422
    print("  ✓ Invalid tier → 422 correctly returned")


def test_predict_negative_recency():
    """POST /predict with negative recency_days → 422"""
    bad = {**LOW_RISK_CUSTOMER, "recency_days": -5}
    response = client.post("/predict", json=bad)
    assert response.status_code == 422
    print("  ✓ Negative recency → 422 correctly returned")


def test_predict_return_rate_exceeds_one():
    """POST /predict with return_rate > 1.0 → 422"""
    bad = {**LOW_RISK_CUSTOMER, "return_rate": 1.5}
    response = client.post("/predict", json=bad)
    assert response.status_code == 422
    print("  ✓ return_rate > 1.0 → 422 correctly returned")


def test_predict_negative_tickets_exceed_total():
    """POST /predict with n_negative_tickets > n_support_tickets → 422"""
    bad = {**HIGH_RISK_CUSTOMER, "n_negative_tickets": 10, "n_support_tickets": 2}
    response = client.post("/predict", json=bad)
    assert response.status_code == 422
    print("  ✓ n_negative_tickets > n_support_tickets → 422 correctly returned")


def test_predict_missing_required_field():
    """POST /predict missing required field recency_days → 422"""
    bad = {k: v for k, v in LOW_RISK_CUSTOMER.items() if k != "recency_days"}
    response = client.post("/predict", json=bad)
    assert response.status_code == 422
    print("  ✓ Missing required field → 422 correctly returned")


# ─── TEST: BATCH PREDICT ──────────────────────────────────────────────────────
def test_batch_predict_multiple_customers():
    """POST /batch_predict with 3 customers → all predictions returned"""
    payload = {"customers": [LOW_RISK_CUSTOMER, HIGH_RISK_CUSTOMER, MEDIUM_RISK_CUSTOMER]}
    response = client.post("/batch_predict", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["total"] == 3
    assert len(body["predictions"]) == 3
    assert "high_risk_count" in body
    print(f"  ✓ Batch (3 customers) → total={body['total']}, high_risk={body['high_risk_count']}")


def test_batch_predict_empty_list():
    """POST /batch_predict with empty list → 400 Bad Request"""
    response = client.post("/batch_predict", json={"customers": []})
    assert response.status_code == 400
    print("  ✓ Empty batch → 400 correctly returned")


def test_batch_predict_high_risk_count():
    """POST /batch_predict high_risk_count should match predictions with risk_level=high"""
    payload = {"customers": [HIGH_RISK_CUSTOMER, HIGH_RISK_CUSTOMER, LOW_RISK_CUSTOMER]}
    response = client.post("/batch_predict", json=payload)
    body = response.json()
    computed_high = sum(1 for p in body["predictions"] if p["risk_level"] == "high")
    assert body["high_risk_count"] == computed_high
    print(f"  ✓ high_risk_count={body['high_risk_count']} matches computed={computed_high}")


def test_batch_predict_single_customer():
    """POST /batch_predict with 1 customer should work like /predict"""
    payload = {"customers": [MEDIUM_RISK_CUSTOMER]}
    response = client.post("/batch_predict", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["total"] == 1
    print(f"  ✓ Single-customer batch → prob={body['predictions'][0]['churn_probability']:.3f}")


def test_batch_predict_all_fields_present():
    """Each prediction in batch must contain all required response fields"""
    payload = {"customers": [LOW_RISK_CUSTOMER]}
    response = client.post("/batch_predict", json=payload)
    pred = response.json()["predictions"][0]
    for field in ["churn_probability","predicted_class","risk_level","risk_explanation","threshold_used"]:
        assert field in pred, f"Missing field: {field}"
    print("  ✓ All required fields present in batch prediction")


# ─── RUNNER ───────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    tests = [
        test_health_returns_ok,
        test_health_contains_version,
        test_predict_low_risk_customer,
        test_predict_high_risk_customer,
        test_predict_returns_explanation,
        test_predict_threshold_field,
        test_predict_optional_customer_id,
        test_predict_invalid_tier,
        test_predict_negative_recency,
        test_predict_return_rate_exceeds_one,
        test_predict_negative_tickets_exceed_total,
        test_predict_missing_required_field,
        test_batch_predict_multiple_customers,
        test_batch_predict_empty_list,
        test_batch_predict_high_risk_count,
        test_batch_predict_single_customer,
        test_batch_predict_all_fields_present,
    ]

    passed = 0
    failed = 0
    print("\n" + "="*60)
    print("  D2C Churn API — Test Suite")
    print("="*60)

    for test in tests:
        try:
            print(f"\n[TEST] {test.__name__}")
            test()
            passed += 1
        except Exception as e:
            print(f"  ✗ FAILED: {e}")
            failed += 1

    print("\n" + "="*60)
    print(f"  Results: {passed} passed, {failed} failed")
    print("="*60)
    if failed:
        sys.exit(1)
