# Model Card: D2C Customer Churn Prediction Model

**Model Name:** D2C Churn Scorer v1.0  
**Model Type:** Gradient Boosting Classifier (scikit-learn GradientBoostingClassifier)  
**Version:** 1.0  
**Created:** July 2024  
**Owner:** Analytics Team  

---

## 1. Intended Use

### Primary Use Case
Predict the probability that a given customer will churn (no purchase) within the next 60 days of the snapshot date. Outputs are intended to support the CRM team in prioritizing outreach to at-risk customers.

### Intended Users
- CRM and retention team (receives risk scores for campaign targeting)
- Marketing team (uses segment-level outputs to design offers)
- Customer success team (uses individual scores for personal outreach)
- Product team (uses aggregate risk signals for feature prioritization)

### Out-of-Scope Uses
- **Do not use** for credit scoring, loan approvals, or any financial decision-making
- **Do not use** to determine employee compensation or performance
- **Do not use** to automatically block customer accounts or reduce service levels
- **Do not use** as the sole input for any high-stakes irreversible decision affecting a customer

---

## 2. Data Used

### Training Data
| Dataset | Records | Date Range |
|---|---|---|
| orders.csv | 10,219 orders | 2022-01-01 to 2024-06-30 |
| customers.csv | 3,000 customers | Snapshot: 2024-06-30 |
| support_tickets.csv | 2,759 tickets | 2022-01-01 to 2024-06-30 |
| web_app_events.csv | 58,342 events | 2022-01-01 to 2024-06-30 |
| campaigns.csv | 7,495 interactions | 2022-01-01 to 2024-06-30 |

**Target Definition:** Churned = 1 if customer made no purchase within 60 days after snapshot date (2024-06-30). Otherwise 0.

**Churn Rate in Training Data:** 73.97%

### Data Splits
| Split | Size | Churn Rate |
|---|---|---|
| Train | 2,101 | 73.96% |
| Validation | 449 | 73.94% |
| Test | 450 | 74.00% |

### Leakage Prevention
All features are derived exclusively from data on or before the snapshot date (2024-06-30). The target variable (churned) is derived from post-snapshot behavior and is **never** used as an input feature.

---

## 3. Features Used

### Top 10 Most Important Features

| Rank | Feature | Importance | Description |
|---|---|---|---|
| 1 | recency_days | 0.249 | Days since last order |
| 2 | log_recency | 0.156 | Log-transformed recency |
| 3 | membership_tier_Bronze | 0.081 | Is customer in Bronze tier |
| 4 | events_per_day | 0.070 | Web/app events normalized by tenure |
| 5 | n_web_events | 0.064 | Total digital engagement events |
| 6 | days_since_join | 0.057 | Customer tenure in days |
| 7 | avg_order_value | 0.046 | Average net order amount |
| 8 | avg_discount_pct | 0.042 | Average discount used |
| 9 | monetary_per_order | 0.035 | Monetary value normalized by frequency |
| 10 | log_monetary | 0.023 | Log-transformed total spend |

**Total features:** 30 (22 numeric + 8 one-hot encoded categorical)

---

## 4. Model Approach

### Algorithm
Gradient Boosting Classifier (scikit-learn `GradientBoostingClassifier`)

### Hyperparameters
| Parameter | Value |
|---|---|
| n_estimators | 150 |
| learning_rate | 0.05 |
| max_depth | 4 |
| subsample | 0.8 |
| random_state | 42 |

### Preprocessing
- Numeric features: StandardScaler
- Categorical features: OneHotEncoder (handle_unknown="ignore")
- All steps included in a single sklearn Pipeline (saved as model.pkl)

### Baseline Comparison
| Model | ROC-AUC | PR-AUC | F1 (val) |
|---|---|---|---|
| Logistic Regression (baseline) | 0.832 | 0.917 | 0.820 |
| Random Forest | 0.836 | 0.916 | 0.846 |
| **Gradient Boosting (selected)** | **0.837** | **0.921** | **0.881** |

---

## 5. Performance

### Decision Threshold
**Selected threshold: 0.45**

**Rationale:** The cost of a missed churner (lost customer lifetime value, typically ₹5,000–₹50,000) significantly exceeds the cost of an unnecessary intervention (campaign message, ₹20–₹200). Therefore, we lower the threshold from 0.5 to 0.45 to increase recall at the expense of some precision.

### Test Set Results (threshold = 0.45)

| Metric | Value |
|---|---|
| Accuracy | 78.4% |
| Precision | 82.1% |
| Recall | **90.7%** |
| F1-Score | 86.2% |
| ROC-AUC | 81.6% |
| PR-AUC | **92.4%** |

### Confusion Matrix (Test Set, n=450)

| | Predicted: Retained | Predicted: Churned |
|---|---|---|
| **Actual: Retained** | TN = 51 | FP = 66 |
| **Actual: Churned** | FN = 31 | TP = 302 |

### Interpretation
- The model correctly identifies **302 of 333 actual churners** (91% recall)
- **31 high-risk customers are missed** — concentrated in Platinum/Gold tier with recent orders
- **66 customers are over-flagged** — mostly Bronze-tier with long recency who returned anyway

---

## 6. Limitations

1. **Recency dominance:** The model heavily weights recency (>40% combined importance). This makes it very accurate for dormant customers but misses churn in recently-active Platinum customers.

2. **No sentiment NLP:** Ticket sentiment is captured only as a count of negative labels, not the actual content. A natural language model on ticket text would likely improve FN rate for high-value customers.

3. **No competitor/external signals:** Price comparison behavior, social media sentiment, and competitor promotions are not in the model — all known drivers of churn from qualitative research.

4. **Synthetic churn label:** The 60-day churn window definition may not match business reality. Some customers naturally buy every 90–120 days (body care, supplements) and should not be labelled churned at Day 60.

5. **High base churn rate:** A 74% churn rate in training data means even a naive "always churn" classifier would achieve 74% accuracy. Always evaluate on precision, recall, and PR-AUC, not accuracy alone.

6. **No cohort segmentation:** The model treats all customers the same. A Platinum customer and a Bronze customer with the same recency have very different retention economics.

---

## 7. Ethical Risks

| Risk | Severity | Mitigation |
|---|---|---|
| Discriminatory discounting | Medium | Do not use churn score to deny loyal customers promotions that new customers receive |
| Privacy of behavioural data | High | Ensure all customer-level data is processed in compliance with data protection regulations |
| Automation bias | Medium | Require human review for high-value customers (LTV > ₹20K) before any intervention |
| Self-fulfilling prophecy | Low | Customers classified as "dormant" should not receive reduced service quality |
| Systematic mis-scoring | Medium | Audit model performance quarterly by membership tier, city, and acquisition channel |

---

## 8. Monitoring Requirements

### Metrics to Track in Production

| Metric | Frequency | Alert Threshold |
|---|---|---|
| Prediction distribution (mean churn prob) | Weekly | ±10% from baseline mean |
| Actual churn rate vs predicted | Monthly | Precision < 75% or Recall < 85% |
| Feature distribution drift | Monthly | PSI > 0.2 for any top-5 feature |
| API error rate | Daily | > 1% error rate |
| False negative rate by tier | Monthly | FN rate for Platinum > 15% |

### Retraining Triggers
- Actual churn rate shifts by > ±8 percentage points over two consecutive months
- Model F1-score on a hold-out validation set drops below 0.78
- A major product, pricing, or business model change occurs
- More than 6 months have passed since last training

---

## 9. When NOT to Use This Model

- When the business is running a major campaign or product launch — customer behavior will deviate from training patterns
- For customers who joined less than 30 days ago — insufficient behavioral history
- For B2B or wholesale accounts — model was trained on D2C individual purchase behavior only
- As a substitute for direct customer feedback or NPS data — model captures behavioral signals, not satisfaction

---

## 10. Contact & Governance

- **Model owner:** Analytics Team
- **Deployment environment:** Internal CRM API (Part 4)
- **Review cycle:** Quarterly
- **Escalation path:** Any ethical concerns → Head of Data, then Legal
