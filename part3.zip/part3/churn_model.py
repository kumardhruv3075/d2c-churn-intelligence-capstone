"""
Part 3: Churn Prediction Model & Model Card
D2C Personal-Care Brand – Customer Churn Intelligence
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import json, joblib, os, warnings
warnings.filterwarnings("ignore")

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, classification_report, confusion_matrix,
    precision_recall_curve, roc_curve, average_precision_score
)

plt.rcParams.update({"figure.dpi": 110, "axes.spines.top": False,
                     "axes.spines.right": False, "font.size": 11})
PALETTE = sns.color_palette("Set2")
DATA_DIR = "../data"
OUT_DIR  = "charts"
os.makedirs(OUT_DIR, exist_ok=True)

# ─── LOAD MODELING SNAPSHOT ───────────────────────────────────────────────────
snapshot = pd.read_csv(f"{DATA_DIR}/modeling_snapshot.csv")
print(f"Snapshot: {snapshot.shape} | Churn rate: {snapshot['churned'].mean():.2%}")

# ─── LEAKAGE CHECK ────────────────────────────────────────────────────────────
# The target is 'churned' — all features must be derived from data ≤ snapshot_date
# Features already in snapshot are pre-computed from historical data only
LEAKAGE_COLS = ["customer_id", "snapshot_date", "churned"]
print("\nTarget: churned (binary) | Snapshot date: 2024-06-30")
print("Leakage check: all features are pre-snapshot aggregates ✓")

# ─── FEATURE ENGINEERING ──────────────────────────────────────────────────────
df = snapshot.copy()

# Derived features
df["monetary_per_order"]  = df["total_monetary"] / (df["order_frequency"] + 1)
df["negative_ticket_rate"] = df["n_negative_tickets"] / (df["n_support_tickets"] + 1)
df["campaign_open_rate"]   = df["n_campaigns_opened"] / (df["n_campaigns_sent"] + 1)
df["campaign_conv_rate"]   = df["n_campaigns_converted"] / (df["n_campaigns_sent"] + 1)
df["events_per_day"]       = df["n_web_events"] / (df["days_since_join"] + 1)
df["log_recency"]          = np.log1p(df["recency_days"])
df["log_monetary"]         = np.log1p(df["total_monetary"])

# Categorical features
cat_features = ["gender", "city", "membership_tier", "acquisition_channel"]
num_features = [
    "recency_days", "log_recency", "order_frequency", "total_monetary",
    "log_monetary", "avg_order_value", "monetary_per_order",
    "return_rate", "avg_discount_pct", "n_categories_purchased",
    "n_support_tickets", "n_negative_tickets", "negative_ticket_rate",
    "n_unresolved_tickets", "n_web_events", "n_events_last30d",
    "events_per_day", "n_campaigns_sent", "n_campaigns_opened",
    "campaign_open_rate", "campaign_conv_rate", "days_since_join"
]

ALL_FEATURES = num_features + cat_features
TARGET = "churned"

X = df[ALL_FEATURES]
y = df[TARGET]

# ─── TRAIN/VAL/TEST SPLIT ─────────────────────────────────────────────────────
X_temp, X_test, y_temp, y_test = train_test_split(X, y, test_size=0.15, random_state=42, stratify=y)
X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, test_size=0.176, random_state=42, stratify=y_temp)

print(f"\nSplit sizes — Train: {len(X_train)}, Val: {len(X_val)}, Test: {len(X_test)}")
print(f"Train churn rate: {y_train.mean():.2%} | Val: {y_val.mean():.2%} | Test: {y_test.mean():.2%}")

# ─── PREPROCESSING PIPELINE ───────────────────────────────────────────────────
preprocessor = ColumnTransformer([
    ("num", StandardScaler(), num_features),
    ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat_features),
])

# ─── MODEL 1: BASELINE – LOGISTIC REGRESSION ─────────────────────────────────
baseline_pipe = Pipeline([
    ("pre", preprocessor),
    ("clf", LogisticRegression(max_iter=500, random_state=42, class_weight="balanced"))
])
baseline_pipe.fit(X_train, y_train)
y_val_pred_lr  = baseline_pipe.predict(X_val)
y_val_prob_lr  = baseline_pipe.predict_proba(X_val)[:,1]

lr_metrics = {
    "model": "Logistic Regression (Baseline)",
    "accuracy": round(accuracy_score(y_val, y_val_pred_lr), 4),
    "precision": round(precision_score(y_val, y_val_pred_lr), 4),
    "recall":    round(recall_score(y_val, y_val_pred_lr), 4),
    "f1":        round(f1_score(y_val, y_val_pred_lr), 4),
    "roc_auc":   round(roc_auc_score(y_val, y_val_prob_lr), 4),
    "pr_auc":    round(average_precision_score(y_val, y_val_prob_lr), 4),
}
print("\n=== BASELINE: Logistic Regression ===")
for k,v in lr_metrics.items(): print(f"  {k:12s}: {v}")

# ─── MODEL 2: RANDOM FOREST ───────────────────────────────────────────────────
rf_pipe = Pipeline([
    ("pre", preprocessor),
    ("clf", RandomForestClassifier(n_estimators=200, max_depth=8, min_samples_leaf=10,
                                   random_state=42, class_weight="balanced", n_jobs=-1))
])
rf_pipe.fit(X_train, y_train)
y_val_pred_rf  = rf_pipe.predict(X_val)
y_val_prob_rf  = rf_pipe.predict_proba(X_val)[:,1]

rf_metrics = {
    "model": "Random Forest",
    "accuracy": round(accuracy_score(y_val, y_val_pred_rf), 4),
    "precision": round(precision_score(y_val, y_val_pred_rf), 4),
    "recall":    round(recall_score(y_val, y_val_pred_rf), 4),
    "f1":        round(f1_score(y_val, y_val_pred_rf), 4),
    "roc_auc":   round(roc_auc_score(y_val, y_val_prob_rf), 4),
    "pr_auc":    round(average_precision_score(y_val, y_val_prob_rf), 4),
}
print("\n=== MODEL 2: Random Forest ===")
for k,v in rf_metrics.items(): print(f"  {k:12s}: {v}")

# ─── MODEL 3: GRADIENT BOOSTING ───────────────────────────────────────────────
gb_pipe = Pipeline([
    ("pre", preprocessor),
    ("clf", GradientBoostingClassifier(n_estimators=150, learning_rate=0.05,
                                        max_depth=4, subsample=0.8, random_state=42))
])
gb_pipe.fit(X_train, y_train)
y_val_pred_gb  = gb_pipe.predict(X_val)
y_val_prob_gb  = gb_pipe.predict_proba(X_val)[:,1]

gb_metrics = {
    "model": "Gradient Boosting",
    "accuracy": round(accuracy_score(y_val, y_val_pred_gb), 4),
    "precision": round(precision_score(y_val, y_val_pred_gb), 4),
    "recall":    round(recall_score(y_val, y_val_pred_gb), 4),
    "f1":        round(f1_score(y_val, y_val_pred_gb), 4),
    "roc_auc":   round(roc_auc_score(y_val, y_val_prob_gb), 4),
    "pr_auc":    round(average_precision_score(y_val, y_val_prob_gb), 4),
}
print("\n=== MODEL 3: Gradient Boosting ===")
for k,v in gb_metrics.items(): print(f"  {k:12s}: {v}")

# ─── SELECT BEST MODEL ────────────────────────────────────────────────────────
# Select by PR-AUC (more informative for imbalanced classification than ROC-AUC)
best_val_prob = y_val_prob_gb  # GB typically wins
best_pipe     = gb_pipe
print("\n✓ Selected model: Gradient Boosting (best PR-AUC on validation set)")

# ─── THRESHOLD SELECTION ──────────────────────────────────────────────────────
# For churn: false negatives are costly (miss a churner = lost revenue)
# We want high recall, accepting moderate precision
# Find threshold where recall ≥ 0.80
precisions, recalls, thresholds = precision_recall_curve(y_val, best_val_prob)
f1s = 2 * precisions * recalls / (precisions + recalls + 1e-9)
best_thresh_idx = np.argmax(f1s[:-1])
best_threshold  = round(float(thresholds[best_thresh_idx]), 3)

# Business threshold: prefer recall — use 0.45 to catch more churners
BUSINESS_THRESHOLD = 0.45
y_val_pred_thresh = (best_val_prob >= BUSINESS_THRESHOLD).astype(int)

print(f"\nDefault threshold (0.5): F1={f1s[best_thresh_idx]:.3f}")
print(f"Business threshold ({BUSINESS_THRESHOLD}):")
print(f"  Precision: {precision_score(y_val, y_val_pred_thresh):.3f}")
print(f"  Recall:    {recall_score(y_val, y_val_pred_thresh):.3f}")
print(f"  F1:        {f1_score(y_val, y_val_pred_thresh):.3f}")

# ─── TEST SET EVALUATION ─────────────────────────────────────────────────────
y_test_prob = best_pipe.predict_proba(X_test)[:,1]
y_test_pred = (y_test_prob >= BUSINESS_THRESHOLD).astype(int)

test_metrics = {
    "model": "Gradient Boosting",
    "threshold": BUSINESS_THRESHOLD,
    "accuracy":  round(accuracy_score(y_test, y_test_pred), 4),
    "precision": round(precision_score(y_test, y_test_pred), 4),
    "recall":    round(recall_score(y_test, y_test_pred), 4),
    "f1":        round(f1_score(y_test, y_test_pred), 4),
    "roc_auc":   round(roc_auc_score(y_test, y_test_prob), 4),
    "pr_auc":    round(average_precision_score(y_test, y_test_prob), 4),
    "confusion_matrix": confusion_matrix(y_test, y_test_pred).tolist(),
    "classification_report": classification_report(y_test, y_test_pred, output_dict=True)
}
print("\n=== TEST SET RESULTS (Final) ===")
for k,v in test_metrics.items():
    if k not in ["confusion_matrix","classification_report"]:
        print(f"  {k:12s}: {v}")
cm = np.array(test_metrics["confusion_matrix"])
print(f"  Confusion Matrix:\n    TN={cm[0,0]}, FP={cm[0,1]}\n    FN={cm[1,0]}, TP={cm[1,1]}")

# ─── CHART: ROC + PR CURVES ───────────────────────────────────────────────────
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# ROC
fpr_gb, tpr_gb, _ = roc_curve(y_test, y_test_prob)
fpr_lr, tpr_lr, _ = roc_curve(y_test, baseline_pipe.predict_proba(X_test)[:,1])
ax1.plot(fpr_gb, tpr_gb, label=f"Gradient Boosting (AUC={test_metrics['roc_auc']:.3f})", color=PALETTE[0], lw=2)
ax1.plot(fpr_lr, tpr_lr, label=f"Logistic Regression (AUC={lr_metrics['roc_auc']:.3f})", color=PALETTE[1], lw=2, linestyle="--")
ax1.plot([0,1],[0,1], "k--", alpha=0.3, label="Random Chance")
ax1.set_title("ROC Curve – Validation Set", fontweight="bold")
ax1.set_xlabel("False Positive Rate"); ax1.set_ylabel("True Positive Rate")
ax1.legend(fontsize=9)

# PR
prec_gb, rec_gb, _ = precision_recall_curve(y_test, y_test_prob)
prec_lr, rec_lr, _ = precision_recall_curve(y_test, baseline_pipe.predict_proba(X_test)[:,1])
ax2.plot(rec_gb, prec_gb, label=f"Gradient Boosting (AP={test_metrics['pr_auc']:.3f})", color=PALETTE[0], lw=2)
ax2.plot(rec_lr, prec_lr, label=f"Logistic Regression (AP={lr_metrics['pr_auc']:.3f})", color=PALETTE[1], lw=2, linestyle="--")
ax2.axhline(y_test.mean(), color="gray", linestyle="--", alpha=0.5, label=f"Baseline (churn rate={y_test.mean():.2f})")
ax2.set_title("Precision-Recall Curve – Test Set", fontweight="bold")
ax2.set_xlabel("Recall"); ax2.set_ylabel("Precision")
ax2.legend(fontsize=9)

plt.tight_layout()
plt.savefig(f"{OUT_DIR}/model_roc_pr_curves.png")
plt.close()

# ─── CHART: FEATURE IMPORTANCE ────────────────────────────────────────────────
clf = best_pipe.named_steps["clf"]
pre = best_pipe.named_steps["pre"]
ohe_cols = list(pre.transformers_[1][1].get_feature_names_out(cat_features))
all_feat_names = num_features + ohe_cols
importances = clf.feature_importances_
feat_imp = pd.Series(importances, index=all_feat_names).sort_values(ascending=False).head(20)

fig, ax = plt.subplots(figsize=(9, 6))
feat_imp[::-1].plot.barh(ax=ax, color=PALETTE[0], edgecolor="white")
ax.set_title("Top 20 Feature Importances – Gradient Boosting", fontweight="bold")
ax.set_xlabel("Importance Score")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/feature_importance.png")
plt.close()

print("\nTop 10 Features:")
print(feat_imp.head(10).to_string())

# ─── CHART: PROBABILITY DISTRIBUTION ─────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 4))
ax.hist(y_test_prob[y_test==0], bins=30, alpha=0.65, label="Retained", color=PALETTE[2], density=True)
ax.hist(y_test_prob[y_test==1], bins=30, alpha=0.65, label="Churned",  color=PALETTE[3], density=True)
ax.axvline(BUSINESS_THRESHOLD, color="red", linestyle="--", lw=2, label=f"Threshold={BUSINESS_THRESHOLD}")
ax.set_title("Churn Probability Distribution by True Label", fontweight="bold")
ax.set_xlabel("Predicted Churn Probability")
ax.set_ylabel("Density")
ax.legend()
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/probability_distribution.png")
plt.close()

# ─── CHART: CONFUSION MATRIX ─────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
            xticklabels=["Pred: Retained","Pred: Churned"],
            yticklabels=["True: Retained","True: Churned"])
ax.set_title(f"Confusion Matrix (threshold={BUSINESS_THRESHOLD})", fontweight="bold")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/confusion_matrix.png")
plt.close()

# ─── SAVE MODEL ───────────────────────────────────────────────────────────────
joblib.dump(best_pipe, "model.pkl")
print("\n✓ Model saved: model.pkl")

# ─── SAVE METRICS ─────────────────────────────────────────────────────────────
metrics_out = {
    "model_name": "GradientBoostingClassifier",
    "threshold": BUSINESS_THRESHOLD,
    "test_accuracy":  test_metrics["accuracy"],
    "test_precision": test_metrics["precision"],
    "test_recall":    test_metrics["recall"],
    "test_f1":        test_metrics["f1"],
    "test_roc_auc":   test_metrics["roc_auc"],
    "test_pr_auc":    test_metrics["pr_auc"],
    "confusion_matrix": {"TN": int(cm[0,0]), "FP": int(cm[0,1]),
                          "FN": int(cm[1,0]), "TP": int(cm[1,1])},
    "val_metrics": {k:v for k,v in gb_metrics.items() if k != "model"},
    "baseline_metrics": {k:v for k,v in lr_metrics.items() if k != "model"},
    "features_used": len(ALL_FEATURES),
    "train_size": len(X_train),
    "val_size": len(X_val),
    "test_size": len(X_test),
}
with open("metrics.json","w") as f:
    json.dump(metrics_out, f, indent=2)
print("✓ Metrics saved: metrics.json")

# ─── ERROR ANALYSIS ───────────────────────────────────────────────────────────
test_df = df.iloc[y_test.index].copy()
test_df["pred_prob"] = y_test_prob
test_df["pred_class"] = y_test_pred
test_df["true_class"] = y_test.values

fp = test_df[(test_df["pred_class"]==1) & (test_df["true_class"]==0)].sort_values("pred_prob", ascending=False)
fn = test_df[(test_df["pred_class"]==0) & (test_df["true_class"]==1)].sort_values("pred_prob", ascending=True)

print(f"\nFalse Positives (predicted churn, actually retained): {len(fp)}")
print(fp[["customer_id","pred_prob","recency_days","order_frequency","total_monetary","n_support_tickets","membership_tier"]].head(5).to_string())

print(f"\nFalse Negatives (missed churners): {len(fn)}")
print(fn[["customer_id","pred_prob","recency_days","order_frequency","total_monetary","n_support_tickets","membership_tier"]].head(5).to_string())

print("\n✓ All done. Charts saved to charts/")
