# Part 3 — Churn Prediction Model & Model Card
## D2C Customer Churn Intelligence

### Overview
This repository trains and evaluates a churn prediction model for a D2C personal-care brand. The model predicts the probability that a customer will not purchase within 60 days of the snapshot date (2024-06-30). A Gradient Boosting Classifier achieves **ROC-AUC 0.816**, **Recall 0.907**, and **PR-AUC 0.924** on the held-out test set.

---

### Repository Structure

```
part3/
├── README.md              ← This file
├── churn_model.ipynb      ← Full modeling notebook
├── churn_model.py         ← Python script version
├── model.pkl              ← Trained Gradient Boosting pipeline (joblib)
├── metrics.json           ← Test set evaluation metrics
├── error_analysis.md      ← FP/FN analysis with 10 specific customers
├── model_card.md          ← Structured model card
├── requirements.txt       ← Python dependencies
└── charts/
    ├── model_roc_pr_curves.png
    ├── feature_importance.png
    ├── probability_distribution.png
    └── confusion_matrix.png
```

---

### Setup & Run

```bash
pip install -r requirements.txt

# Train model and generate all outputs
python churn_model.py

# Or use notebook
jupyter notebook churn_model.ipynb
```

Data must be in `../data/` relative to this directory.

---

### Model Summary

| Component | Detail |
|---|---|
| Algorithm | GradientBoostingClassifier |
| Features | 30 (numeric + one-hot categorical) |
| Train/Val/Test | 2101 / 449 / 450 |
| Churn base rate | 73.97% |
| Decision threshold | 0.45 (recall-optimized) |

### Test Metrics

| Metric | Value |
|---|---|
| Accuracy | 78.4% |
| Precision | 82.1% |
| **Recall** | **90.7%** |
| F1-Score | 86.2% |
| ROC-AUC | 81.6% |
| **PR-AUC** | **92.4%** |

### Load & Use the Model

```python
import joblib, pandas as pd

model = joblib.load("model.pkl")
# X must contain the same feature columns as training
probs = model.predict_proba(X)[:, 1]
preds = (probs >= 0.45).astype(int)
```

---

### Leakage Prevention

All features are aggregates computed from data on or before **2024-06-30** (snapshot date). The churn label is derived from post-snapshot behavior and is never used as an input. See `churn_model.py` for explicit leakage checks.

---

### Key Findings

- **Recency is the strongest predictor** (25% feature importance) — days since last order dominates
- **Bronze tier membership** is the 3rd most important feature, acting as a proxy for low engagement depth
- **False Positives:** Mostly Bronze-tier customers with 300+ day recency who happened to retain
- **False Negatives:** Platinum-tier customers with recent orders who churned — likely competitor captures or satisfaction-driven exits not visible in behavioral data
