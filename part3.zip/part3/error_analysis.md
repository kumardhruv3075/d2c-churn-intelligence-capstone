# Error Analysis: Churn Prediction Model
## D2C Personal-Care Brand – Part 3

**Model:** Gradient Boosting Classifier  
**Threshold:** 0.45  
**Test Set Confusion Matrix:** TN=51, FP=66, FN=31, TP=302  

---

## 1. Error Overview

| Error Type | Count | Business Risk |
|---|---|---|
| True Positives (correctly flagged churners) | 302 | — |
| True Negatives (correctly retained) | 51 | — |
| **False Positives** (predicted churn, actually retained) | **66** | Wasted retention spend; may annoy loyal customers |
| **False Negatives** (missed churners) | **31** | Lost revenue; no intervention triggered |

**Overall error rate on test set: 21.6%**

At threshold 0.45, the model prioritizes recall (91%) over precision (82%), which is the correct business trade-off for churn: missing a churner is more expensive than over-intervening.

---

## 2. False Positive Analysis

> "We predicted churn, but the customer actually stayed."

### What does a False Positive look like?

False Positives in this model are predominantly **Bronze-tier customers with long recency who were ultimately retained by some low-cost interaction** (e.g., a campaign conversion or a single return purchase) that the model couldn't see.

### Key Patterns in FP Cases

| Signal | FP Average | FN Average | Overall Average |
|---|---|---|---|
| Recency Days | ~350 days | ~25 days | 120 days |
| Order Frequency | ~1.5 orders | ~9.5 orders | 3.5 orders |
| Membership Tier | Mostly Bronze | Mostly Platinum | Mixed |
| Support Tickets | 1.2 avg | 1.0 avg | 0.9 avg |

### Specific False Positive Examples

**Case FP-1 — C02637**
- Recency: 542 days | Frequency: 1 order | Spend: ₹1,267
- Predicted: Churned (prob=0.971) | Actual: **Retained**
- 4 support tickets
- **Analysis:** The model correctly identified this as very high risk based on 542-day inactivity. The customer was technically still active in the label window (perhaps made a micro-purchase or reactivated). The model's assessment is likely correct about the fragility of this relationship.
- **Business Risk:** Low — sending a winback offer to someone who just barely stayed is not harmful.

**Case FP-2 — C00830**
- Recency: 436 days | Frequency: 1 order | Spend: ₹1,828
- Predicted: Churned (prob=0.962) | Actual: **Retained**
- 0 support tickets, Bronze tier
- **Analysis:** One-time buyer who was away for 14+ months but returned. The model is not wrong to flag this — any customer with 436-day recency is at extreme risk. This customer may have returned due to a targeted campaign not visible in the features.
- **Business Risk:** Low. Sending a campaign to a customer with 436-day recency who is "retained" is still good practice.

**Case FP-3 — C00418**
- Recency: 407 days | Frequency: 1 order | Spend: ₹6,600
- Predicted: Churned (prob=0.960) | Actual: **Retained**
- Bronze tier, no tickets
- **Analysis:** Higher spend (₹6,600) for a single order. The model over-extends the recency signal here — this customer may be a "big but infrequent" buyer rather than a churner. Worth flagging for the retention team regardless.
- **Business Risk:** Moderate — sending a discount to a naturally infrequent high-value buyer could unnecessarily erode margin.

**Case FP-4 — C01596**
- Recency: 102 days | Frequency: 3 orders | Spend: ₹20,206
- Predicted: Churned (prob=0.954) | Actual: **Retained**
- Bronze tier, 1 support ticket
- **Analysis:** High-value customer with moderate recency. The Bronze tier pushes the model's risk estimate up. This is a segmentation/threshold issue — this customer may warrant a reclassification to Silver.
- **Business Risk:** **Higher** — this is a ₹20K customer who does NOT need aggressive retention. Sending an unnecessary discount erodes margin significantly.

**Case FP-5 — C01278**
- Recency: 80 days | Frequency: 3 orders | Spend: ₹16,644
- Predicted: Churned (prob=0.947) | Actual: **Retained**
- Bronze tier, 0 tickets
- **Analysis:** Similar to FP-4. High-spend Bronze customer flagged due to 80-day recency and tier classification. The model's Bronze tier signal may be overcorrecting for these mid-recency, high-spend customers.
- **Business Risk:** **Higher** — intervention here should be light-touch (loyalty points, not discounts).

---

## 3. False Negative Analysis

> "We predicted they'd stay, but they actually churned."

### What does a False Negative look like?

False Negatives are concentrated among **Platinum/Gold-tier customers with very recent orders and high spend** who churned unexpectedly. These are the most dangerous errors because they represent high-CLV customers the model completely missed.

### Key Patterns in FN Cases

These missed churners "look" like loyal, retained customers:
- Very recent purchases (low recency scores)
- High order frequency
- Platinum membership tier
- Few or no support tickets
- High total spend

The model's bias toward recency as the top feature means it assigns these customers low churn probability — failing to detect an underlying "satisfaction cliff" not captured by behavioural signals.

### Specific False Negative Examples

**Case FN-1 — C02623**
- Recency: 26 days | Frequency: 10 orders | Spend: ₹35,897
- Predicted: Retained (prob=0.064) | Actual: **Churned**
- Platinum tier, 2 support tickets
- **Analysis:** A top-value customer who purchased 26 days ago but still churned. This may indicate competitor acquisition — they made one final purchase then switched. The 2 support tickets may hint at unresolved dissatisfaction not fully reflected in the sentiment data.
- **Business Risk:** **Very High** — ₹36K LTV customer lost, and the model gave zero warning.

**Case FN-2 — C02812**
- Recency: 3 days | Frequency: 7 orders | Spend: ₹23,206
- Predicted: Retained (prob=0.071) | Actual: **Churned**
- Platinum tier, 0 tickets
- **Analysis:** Purchased 3 days before snapshot but is labelled as churned. This is likely a **label timing issue** — the customer's 60-day churn window may have been evaluated incorrectly, or they stopped all further engagement immediately after the purchase. Could be a false churn label.
- **Business Risk:** Moderate — very likely a label artifact. Flag for review before acting.

**Case FN-3 — C02334**
- Recency: 7 days | Frequency: 14 orders | Spend: ₹50,831
- Predicted: Retained (prob=0.081) | Actual: **Churned**
- Platinum tier, 0 tickets
- **Analysis:** Highest-spend false negative in the test set. 14 orders, ₹50K spend, ordered 7 days ago. If the churn label is accurate, this is a catastrophic model failure. More likely this is a label timing issue or an edge case in the 60-day definition window.
- **Business Risk:** **Extremely High** if churn label is accurate. Requires immediate manual follow-up.

**Case FN-4 — C01825**
- Recency: 17 days | Frequency: 11 orders | Spend: ₹35,695
- Predicted: Retained (prob=0.097) | Actual: **Churned**
- Platinum tier, 1 support ticket
- **Analysis:** Strong order history, very recent — yet churned. The single support ticket may have been a breaking-point issue (e.g., damaged product, unresolved complaint). The model misses the qualitative signal in the ticket's impact.
- **Business Risk:** **Very High** — ₹36K customer lost with no intervention triggered.

**Case FN-5 — C02763**
- Recency: 69 days | Frequency: 6 orders | Spend: ₹25,356
- Predicted: Retained (prob=0.136) | Actual: **Churned**
- Platinum tier, 2 support tickets
- **Analysis:** 69-day recency, 2 tickets — slightly more suspicious, but still predicted as retained. The moderate recency (69 days) should have triggered a higher risk score. The model underweights ticket count for Platinum customers.
- **Business Risk:** **High** — ₹25K customer not flagged.

---

## 4. Business Risk Summary

| Error Type | Primary Pattern | Business Impact | Recommended Action |
|---|---|---|---|
| False Positives | Bronze, long recency, actually stayed | Wasted campaign budget (low-spend customers) | Set a spend threshold: only intervene on FPs with LTV > ₹5K |
| False Negatives | Platinum, recent purchase, churned anyway | Lost high-LTV customer with no intervention | Add qualitative signals (ticket tone, NPS) to reduce FN rate |

### Model Improvement Directions

1. **Add NPS/satisfaction score** as a feature — would catch Platinum FN cases where satisfaction has silently dropped
2. **Add competitor-awareness signals** — price comparison app activity, social listening
3. **Separate Platinum customers** into a specialized model with higher weight on ticket sentiment
4. **Review 60-day churn label definition** — several FN cases have recency < 10 days and may be mislabelled

---

## 5. Threshold Sensitivity

| Threshold | Precision | Recall | F1 | FP | FN |
|---|---|---|---|---|---|
| 0.35 | 0.78 | 0.95 | 0.86 | 88 | 17 |
| **0.45** | **0.82** | **0.91** | **0.86** | **66** | **31** |
| 0.50 | 0.86 | 0.87 | 0.86 | 49 | 43 |
| 0.60 | 0.89 | 0.80 | 0.84 | 37 | 66 |

**Selected: 0.45** — balances catching most churners (91% recall) while keeping FP volume manageable. Business cost of a missed churner (lost CLV) exceeds the cost of an unnecessary intervention (small campaign spend).
